"use client";

import Image from "next/image";
import { Fragment, FormEvent, type MouseEvent, useEffect, useMemo, useRef, useState } from "react";
import { CATALOG_PAGE_SIZE, catalogStateFromSearchParams, catalogStateToDealQuery, catalogStateToSearchParams } from "../lib/deal-query";
import type { CatalogState, DealSort, FreshnessBand, PriceBand } from "../lib/deal-query";
import { freshnessLabel, priceFreshness, priceHighlight, priceNarrative, priceSignal, seenAgo } from "../lib/deal-signal";
import { mergeSavedProducts, readSavedState, unionSavedIds, writeSavedState } from "../lib/saved-products";
import type { VitrineProduct } from "../lib/deal-view";
import { MARKETPLACES, marketplaceDef, type MarketplaceDef } from "../lib/marketplaces";
import CopyProductLink from "./_components/copy-product-link";
import { ThemeToggle } from "./theme-toggle";
import { HERO_MAX_PRODUCTS } from "../lib/hero-policy";

type EditorialProduct = VitrineProduct & { editorialRationale: string; editorialContext: string; editorialPurchaseContents: string };

type ApiPage = { selectionVersion?: number | null; selectionStateKey?: string; products: VitrineProduct[]; total: number; categories: string[]; marketplaceCounts: Record<string, number> };
type MobileView = "home" | "categories" | "saved" | "filters" | "menu" | "guide";

const catalogGuide = "Acompanhamos o preço de todas as ofertas daqui. Como isso vale para o catálogo inteiro, não repetimos em cada produto: o selo só aparece quando o histórico tem algo a dizer que o anúncio não diz.";

const priceFilters: Array<{ value: PriceBand; label: string }> = [{ value: "all", label: "todos" }, { value: "under_100", label: "até R$100" }, { value: "100_500", label: "R$100–500" }, { value: "over_500", label: "acima R$500" }];
const sortOptions: Array<{ value: DealSort; label: string }> = [{ value: "signal", label: "ordem editorial" }, { value: "price", label: "menor preço" }, { value: "popularity", label: "mais populares" }, { value: "recent", label: "atualizados agora" }];
const freshnessOptions: Array<{ value: FreshnessBand; label: string }> = [{ value: "today", label: "hoje" }, { value: "2d", label: "últimas 48 horas" }, { value: "3d", label: "últimos 3 dias" }, { value: "7d", label: "últimos 7 dias" }, { value: "14d", label: "últimos 14 dias" }, { value: "all", label: "tudo" }];
const ratingOptions = [{ value: 4, label: "★★★★+" }, { value: 3, label: "★★★+" }, { value: 2, label: "★★+" }];
const discountOptions = [{ value: 30, label: "30%+" }, { value: 50, label: "50%+" }, { value: 70, label: "70%+" }];
const brl = (cents: number) => (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: cents % 100 === 0 ? 0 : 2 });
const historyInput = (product: VitrineProduct) => ({ priceCents: product.priceCents, previousMinPriceCents: product.previousMinPriceCents, observationCount: product.observationCount, historyDays: product.historyDays, lowestVerified: product.lowestVerified });
/** Percentual de desconto declarado pelo anúncio, ou null. Alegação do vendedor — nunca cálculo nosso. */
const discountPercentOf = (product: VitrineProduct): number | null => {
  if (product.discountPercent && product.discountPercent > 0) return product.discountPercent;
  if (product.originalPriceCents && product.originalPriceCents > product.priceCents) {
    return Math.round((1 - product.priceCents / product.originalPriceCents) * 100);
  }
  return null;
};
const discountLabel = (product: VitrineProduct) => {
  const pct = discountPercentOf(product);
  return pct === null ? null : `−${pct}% no anúncio`;
};
const trackInteraction = (event: string, productId?: string) => { if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("bizuminer:interaction", { detail: { event, productId } })); };

function paginationItems(current: number, total: number): Array<number | "ellipsis-left" | "ellipsis-right"> {
  if (total <= 7) return Array.from({ length: total }, (_, index) => index + 1);
  const pages = new Set([1, total, current - 1, current, current + 1]);
  const visible = [...pages].filter((page) => page >= 1 && page <= total).sort((a, b) => a - b);
  const result: Array<number | "ellipsis-left" | "ellipsis-right"> = [];
  visible.forEach((page, index) => {
    const previous = visible[index - 1];
    if (previous && page - previous > 1) result.push(previous === 1 ? "ellipsis-left" : "ellipsis-right");
    result.push(page);
  });
  return result;
}

function MarketplaceEvidence({ product }: { product: VitrineProduct }) {
  if (product.ratingStar === null && !product.salesLabel) return null;
  const evidenceLabel = marketplaceDef(product.marketplace)?.evidenceLabel ?? `dados de ${product.marketplace}`;
  return <p className="product-evidence">
    {product.ratingStar !== null && <span>★ {product.ratingStar.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}</span>}
    {product.ratingStar !== null && product.salesLabel && <i>·</i>}
    {product.salesLabel && <span>{product.salesLabel}</span>}
    {/* A origem é anunciada por quem lê por áudio; visualmente o ícone sobre
        a foto e o texto do CTA já identificam a loja — texto fora da vista. */}
    <span className="sr-only">{evidenceLabel}</span>
  </p>;
}

/**
 * Ícone quadrado da loja, exibido sobre a foto do produto (canto superior
 * esquerdo). Reconhecimento pré-aprendido: o usuário identifica a loja no
 * olhar, antes de ler qualquer texto — mesmo princípio de favicon e ícone
 * de app.
 *
 * Se o arquivo não existir (404) ou não estiver no registro, o ícone some e
 * a loja continua identificada pelo texto do CTA. A checagem de `complete &&
 * naturalWidth === 0` no mount cobre o 404 que acontece antes da hidratação
 * (o `onError` chegaria tarde demais).
 */
function MarketplaceIcon({ logo, className }: { logo?: MarketplaceDef["logo"]; className: string }) {
  const [indisponivel, setIndisponivel] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const img = imgRef.current;
    if (img && img.complete && img.naturalWidth === 0) setIndisponivel(true);
  }, []);

  if (!logo || indisponivel) return null;
  return (
    <span className={className} role="img" aria-label={logo.alt}>
      {/* alt vazio de propósito: quem anuncia é o aria-label do pai, senão o
          leitor de tela repete o nome da loja duas vezes. */}
      <img ref={imgRef} src={logo.src} alt="" onError={() => setIndisponivel(true)} />
    </span>
  );
}

function MarketplaceFilter({ className, active, counts, onChoose }: { className: string; active: string | null; counts: Record<string, number>; onChoose: (marketplace: string | null) => void }) {
  const total = Object.values(counts).reduce((sum, n) => sum + n, 0);
  return <div className={className}>
    <button className={active === null ? "mp-btn active" : "mp-btn"} onClick={() => onChoose(null)} aria-label="Todas as lojas">
      <small>{total > 0 ? total : ""}</small>
    </button>
    {MARKETPLACES.map((def) => <button key={def.slug} className={active === def.slug ? "mp-btn active" : "mp-btn"} onClick={() => onChoose(def.slug)} aria-label={def.label}>
      {def.logo && <img src={def.logo.src} alt="" />}
      {!def.logo && <span>{def.label.charAt(0)}</span>}
      <small>{counts[def.slug] ?? 0}</small>
    </button>)}
  </div>;
}

function SearchForm({ className, id, placeholder, query, disabled, onQuery, onSubmit }: { className: string; id: string; placeholder: string; query: string; disabled: boolean; onQuery: (value: string) => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void }) {
  return <form className={className} onSubmit={onSubmit} role="search">
    <span aria-hidden="true">⌕</span>
    <label className="sr-only" htmlFor={id}>Buscar produtos</label>
    <input id={id} value={query} onChange={(event) => onQuery(event.target.value)} placeholder={placeholder} />
    <button type="submit" disabled={disabled}>buscar</button>
  </form>;
}

function CategoryList({ className, categories, active, onChoose }: { className: string; categories: string[]; active: string | null; onChoose: (category: string | null) => void }) {
  return <div className={className}>
    <button className={active === null ? "active" : ""} onClick={() => onChoose(null)}>todas</button>
    {categories.map((item) => <button key={item} className={active === item ? "active" : ""} onClick={() => onChoose(item)}>{item}</button>)}
  </div>;
}

function EditorialSlide({ products, hidden }: { products: VitrineProduct[]; hidden: boolean }) {
  const primary = products[0];
  const secondary = products[1];
  return <article className="hero-slide hero-editorial-slide" aria-hidden={hidden}>
    <div className="hero-editorial-copy">
      <p className="hero-kicker">Curadoria de ponta a ponta</p>
      <h2>Menos tempo procurando.<br /><em>Mais clareza</em> para decidir.</h2>
      <p>O BizuMiner reúne ofertas, acompanha preços e organiza as evidências que ajudam você a comparar sem abrir dezenas de abas.</p>
      <a href="#achados" tabIndex={hidden ? -1 : undefined}>ver catálogo <b>↓</b></a>
    </div>
    <div className="hero-editorial-board" aria-hidden="true">
      <span className="hero-edition">EDIÇÃO<br /><b>01</b></span>
      <div className="hero-grid-lines" />
      {primary?.imageUrl && <div className="hero-cutout hero-cutout-primary"><Image src={primary.imageUrl} alt="" fill priority sizes="(max-width: 900px) 64vw, 30vw" /></div>}
      {secondary?.imageUrl && <div className="hero-cutout hero-cutout-secondary"><Image src={secondary.imageUrl} alt="" fill sizes="(max-width: 900px) 30vw, 18vw" /></div>}
      <div className="hero-note"><small>COMO ESCOLHEMOS</small><b>utilidade e público</b><b>valor da oferta</b><b>clareza da compra</b></div>
      <span className="hero-tape" />
    </div>
  </article>;
}

function ProductHeroSlide({ product, index, hidden, onImageClick }: { product: EditorialProduct; index: number; hidden: boolean; onImageClick: (event: MouseEvent<HTMLAnchorElement>, productId: string) => void }) {
  const fresh = priceFreshness(product.evidenceObservedAt);
  const status = fresh === "current" ? priceSignal(historyInput(product)) : { tone: "monitoring" as const, label: `última vez visto ${seenAgo(product.evidenceObservedAt)}` };
  return <article className={`hero-slide hero-product-slide hero-product-${index + 1}`} aria-hidden={hidden}>
    <div className="hero-product-copy">
      <p>Destaque {String(index + 2).padStart(2, "0")} · seleção BizuMiner</p>
      <span className={`hero-history-label ${status.tone}`}>{status.label}</span>
      <h2>{product.title}</h2>
      <p className="hero-product-reason">{product.editorialRationale}</p>
      {product.editorialPurchaseContents && <p className="hero-product-contents"><b>O que vem:</b> {product.editorialPurchaseContents}</p>}
      {product.editorialContext && <p className="hero-product-context">{product.editorialContext}</p>}
      <div className="hero-product-facts">
        <span><small>{fresh === "current" ? "preço atual" : "última vez visto"}</small><strong>{brl(product.priceCents)}</strong></span>
        {product.ratingStar !== null && <span><small>{marketplaceDef(product.marketplace)?.ratingLabel ?? `avaliação em ${product.marketplace}`}</small><strong>★ {product.ratingStar.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}</strong></span>}
        {product.salesLabel && <span><small>vendas informadas</small><strong>{product.salesLabel}</strong></span>}
      </div>
      <a href={`/bizu/${product.slug}`} tabIndex={hidden ? -1 : undefined} onClick={() => trackInteraction("hero_detail_click", product.id)}>ver detalhes <b>↗</b></a>
    </div>
    <a className="hero-product-image" href={`/bizu/${product.slug}`} tabIndex={hidden ? -1 : undefined} aria-label={`Ver detalhes de ${product.title}`} onClick={(event) => onImageClick(event, product.id)}>
      <span className="hero-product-number">{String(index + 2).padStart(2, "0")}</span>
      {product.imageUrl ? <Image src={product.imageUrl} alt={product.title} fill sizes="(max-width: 900px) 100vw, 55vw" /> : <div className="image-placeholder"><Image src="/brand/bizuminer-icon-light.svg" alt="BizuMiner" width={32} height={32} /></div>}
      {fresh === "current" && discountLabel(product) && <span className="hero-discount">{discountLabel(product)}</span>}
    </a>
  </article>;
}

export default function Vitrine({ editorialProducts = [], editorialHeroIds = [], editorialHeroValidUntil = null, editorialStateKey = null, editorialVersion = null, initialProducts, initialTotal, initialState, categories: initialCategories, dateLabel, initialSavedIds = [], marketplaceCounts: initialMarketplaceCounts = {}, isUserAdmin = false }: { editorialProducts?: EditorialProduct[]; editorialHeroIds?: string[]; editorialHeroValidUntil?: string | null; editorialStateKey?: string | null; editorialVersion?: number | null; initialProducts: VitrineProduct[]; initialTotal: number; initialState: CatalogState; categories: string[]; dateLabel: string; initialSavedIds?: string[]; marketplaceCounts?: Record<string, number>; isUserAdmin?: boolean }) {
  const [products, setProducts] = useState(initialProducts);
  const [categories, setCategories] = useState(initialCategories);
  const [marketplaceCounts, setMarketplaceCounts] = useState(initialMarketplaceCounts);
  const [mobileProducts, setMobileProducts] = useState(initialProducts);
  const [total, setTotal] = useState(initialTotal);
  const [catalog, setCatalog] = useState(initialState);
  const [mobileLoadedPage, setMobileLoadedPage] = useState(initialState.page);
  const [query, setQuery] = useState(initialState.search);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [favoriteProducts, setFavoriteProducts] = useState<VitrineProduct[]>([]);
  const [favoritesReady, setFavoritesReady] = useState(false);
  const [showSaved, setShowSaved] = useState(false);
  const [mobileView, setMobileView] = useState<MobileView>("home");
  const [categoryQuery, setCategoryQuery] = useState("");
  const [notice, setNotice] = useState("");
  const [currentSlide, setCurrentSlide] = useState(0);
  const [carouselHovered, setCarouselHovered] = useState(false);
  const [carouselFocused, setCarouselFocused] = useState(false);
  const carouselPaused = carouselHovered || carouselFocused;
  const [heroCurrent, setHeroCurrent] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [navOpen, setNavOpen] = useState(false);
  const pointerStart = useRef<number | null>(null);
  const carouselDragged = useRef(false);
  const requestVersion = useRef(0);
  const editorialById = new Map(editorialProducts.map((product) => [product.id, product]));
  const heroProducts = heroCurrent ? editorialHeroIds.slice(0, HERO_MAX_PRODUCTS).flatMap((id) => editorialById.has(id) ? [editorialById.get(id)!] : []) : [];
  const editorialContents = useMemo(() => new Map(editorialProducts.map((product) => [product.id, product.editorialPurchaseContents])), [editorialProducts]);
  const editorialRationales = useMemo(() => new Map(editorialProducts.map((product) => [product.id, product.editorialRationale])), [editorialProducts]);
  const savedProducts = useMemo(() => mergeSavedProducts(favorites, favoriteProducts, [...mobileProducts, ...products]), [favoriteProducts, favorites, mobileProducts, products]);
  const shownProducts = showSaved ? savedProducts : products;
  const totalPages = Math.max(1, Math.ceil(total / CATALOG_PAGE_SIZE));
  const visibleFrom = total === 0 ? 0 : (catalog.page - 1) * CATALOG_PAGE_SIZE + 1;
  const visibleTo = total === 0 ? 0 : visibleFrom + products.length - 1;
  const slideCount = heroProducts.length + 1;
  const featuredProduct = heroProducts[0];
  const filteredCategories = categories.filter((item) => item.toLocaleLowerCase("pt-BR").includes(categoryQuery.trim().toLocaleLowerCase("pt-BR")));
  const discoveryCategories = categories.filter((item) => item !== catalog.category).slice(0, 3);
  const mobileHasMore = mobileLoadedPage < totalPages;

  useEffect(() => {
    const saved = readSavedState(window.localStorage);
    // O localStorage continua a régua local (cache); os ids da conta (servidor)
    // entram na união para a bancada aparecer em qualquer aparelho logado.
    setFavorites(unionSavedIds(saved.ids, initialSavedIds));
    setFavoriteProducts(saved.products);
    setFavoritesReady(true);
  }, [initialSavedIds]);
  useEffect(() => {
    if (!favoritesReady) return;
    writeSavedState(window.localStorage, { ids: favorites, products: favoriteProducts });
  }, [favoriteProducts, favorites, favoritesReady]);
  useEffect(() => {
    if (!favoritesReady) return;
    const next = mergeSavedProducts(favorites, favoriteProducts, [...mobileProducts, ...products]);
    if (JSON.stringify(next) !== JSON.stringify(favoriteProducts)) setFavoriteProducts(next);
  }, [favoriteProducts, favorites, favoritesReady, mobileProducts, products]);
  useEffect(() => {
    if (mobileView === "home") return;
    document.querySelector<HTMLElement>(`#mobile-${mobileView}-title`)?.focus();
  }, [mobileView]);
  useEffect(() => {
    syncUrl(initialState, "replace");
    trackInteraction("catalog_impression");
    const handlePopState = () => {
      const next = catalogStateFromSearchParams(new URLSearchParams(window.location.search));
      setCatalog(next);
      setMobileLoadedPage(next.page);
      setQuery(next.search);
      setShowSaved(false);
      setMobileView("home");
      void fetchDeals(next, true, "replace");
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
    // O estado inicial pertence à navegação que produziu este Server Component.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (carouselPaused) return;
    const timer = window.setTimeout(() => setCurrentSlide((slide) => (slide + 1) % slideCount), 6200);
    return () => window.clearTimeout(timer);
  }, [carouselPaused, currentSlide, slideCount]);
  useEffect(() => {
    if (!editorialStateKey) return;
    const controller = new AbortController();
    let checking = false;
    const invalidate = () => { setHeroCurrent(false); setCurrentSlide(0); };
    const verify = async () => {
      if (document.visibilityState === "hidden" || checking) return;
      checking = true;
      try {
        const response = await fetch("/api/editorial-selection", { cache: "no-store", signal: controller.signal });
        if (!response.ok) return;
        const state = await response.json() as { selectionStateKey: string };
        if (!controller.signal.aborted && state.selectionStateKey !== editorialStateKey) {
          invalidate();
          window.location.reload();
        }
      } catch { /* The local deadline still hides expired highlights. */ }
      finally { checking = false; }
    };
    const deadline = editorialHeroValidUntil ? Date.parse(editorialHeroValidUntil) : NaN;
    const expiry = Number.isFinite(deadline) ? window.setTimeout(() => { invalidate(); void verify(); }, Math.max(0, deadline - Date.now() + 50)) : null;
    const timer = window.setInterval(() => { void verify(); }, 60_000);
    const onVisible = () => { void verify(); };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);
    return () => {
      controller.abort();
      if (expiry !== null) window.clearTimeout(expiry);
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
    };
  }, [editorialHeroIds, editorialHeroValidUntil, editorialStateKey]);

  function syncUrl(next: CatalogState, mode: "push" | "replace") {
    const params = catalogStateToSearchParams(next);
    const url = `${window.location.pathname}${params.size ? `?${params}` : ""}`;
    if (mode === "push") window.history.pushState({}, "", url);
    else window.history.replaceState({}, "", url);
  }

  async function fetchDeals(next: CatalogState, scrollToCatalog: boolean, mode: "replace" | "append" = "replace"): Promise<boolean> {
    const version = ++requestVersion.current;
    setIsLoading(true);
    setLoadError("");
    const dealQuery = catalogStateToDealQuery(next);
    const params = new URLSearchParams({ limit: String(dealQuery.limit), offset: String(dealQuery.offset), sort: dealQuery.sort, price: dealQuery.priceBand });
    if (dealQuery.category) params.set("category", dealQuery.category);
    if (dealQuery.search) params.set("q", dealQuery.search);
    if (dealQuery.marketplace) params.set("marketplace", dealQuery.marketplace);
    params.set("freshness", dealQuery.freshness);
    if (dealQuery.minRating !== null) params.set("minRating", String(dealQuery.minRating));
    if (dealQuery.minDiscount !== null) params.set("minDiscount", String(dealQuery.minDiscount));
    if (dealQuery.lowestOnly) params.set("lowestOnly", "true");
    if (dealQuery.hasHistory) params.set("hasHistory", "true");
    try {
      const response = await fetch(`/api/deals?${params}`);
      if (!response.ok) throw new Error("catalog_failed");
      const page = await response.json() as ApiPage;
      if (version !== requestVersion.current) return false;
      if ((page.selectionStateKey !== undefined && editorialStateKey !== null && page.selectionStateKey !== editorialStateKey)
        || (page.selectionVersion !== undefined && page.selectionVersion !== editorialVersion)) {
        // A nova navegação deve usar a mesma edição no catálogo e no carrossel.
        // A URL já representa os filtros solicitados; a home lê uma única seleção.
        syncUrl(next, "replace");
        window.location.reload();
        return false;
      }
      setProducts(page.products);
      setCategories(page.categories);
      setMarketplaceCounts(page.marketplaceCounts);
      setMobileProducts((current) => mode === "append" ? [...new Map([...current, ...page.products].map((product) => [product.id, product])).values()] : page.products);
      setMobileLoadedPage(next.page);
      setTotal(page.total);
      if (scrollToCatalog) document.querySelector("#achados")?.scrollIntoView({ behavior: "smooth", block: "start" });
      return true;
    } catch {
      if (version === requestVersion.current) setLoadError("Não foi possível atualizar as ofertas agora. Tente de novo.");
      return false;
    } finally {
      if (version === requestVersion.current) setIsLoading(false);
    }
  }

  function changeCatalog(next: CatalogState, mode: "push" | "replace", scrollToCatalog: boolean) {
    setCatalog(next); setMobileLoadedPage(next.page); setShowSaved(false); syncUrl(next, mode); void fetchDeals(next, scrollToCatalog, "replace");
  }
  function showNotice(message: string) { setNotice(message); window.setTimeout(() => setNotice(""), 4200); }
  function toggleFavorite(product: VitrineProduct) {
    const saved = favorites.includes(product.id);
    trackInteraction(saved ? "favorite_remove" : "favorite_add", product.id);
    showNotice(saved ? "Removido dos seus salvos." : "Produto salvo nos seus salvos.");
    setFavorites((current) => saved ? current.filter((item) => item !== product.id) : [...current, product.id]);
    setFavoriteProducts((current) => saved ? current.filter((item) => item.id !== product.id) : mergeSavedProducts([...favorites, product.id], current, [product]));
    // Espelha no servidor (área do comprador); o localStorage segue valendo como cache local.
    void fetch("/api/minha/favoritos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id, saved: !saved }),
    }).catch(() => {});
  }
  function toggleSavedView() {
    if (!showSaved && !favorites.length) { showNotice("Toque no coração de um produto para guardá-lo aqui."); return; }
    setShowSaved((current) => !current);
    document.querySelector("#achados")?.scrollIntoView({ behavior: "smooth" });
  }
  function submitSearch(event: FormEvent<HTMLFormElement>) { event.preventDefault(); trackInteraction("search"); setMobileView("home"); changeCatalog({ ...catalog, page: 1, search: query.trim() }, "replace", true); }
  function clearFilters() { const next: CatalogState = { page: 1, category: null, priceBand: "all", sort: "signal", search: "", marketplace: null, freshness: "2d", minRating: null, minDiscount: null, lowestOnly: false, hasHistory: false }; setQuery(""); setMobileView("home"); changeCatalog(next, "replace", false); }
  function changePage(page: number) {
    if (page < 1 || page > totalPages || page === catalog.page || isLoading) return;
    trackInteraction("page_change"); changeCatalog({ ...catalog, page }, "push", true);
  }
  async function loadMore() {
    if (!mobileHasMore || isLoading) return;
    const next = { ...catalog, page: mobileLoadedPage + 1 };
    const loaded = await fetchDeals(next, false, "append");
    if (!loaded) return;
    setCatalog(next); syncUrl(next, "replace"); trackInteraction("mobile_load_more");
  }
  function chooseCategory(category: string | null) {
    trackInteraction("category_filter"); setMobileView("home"); changeCatalog({ ...catalog, page: 1, category }, "replace", true);
  }
  function chooseMarketplace(marketplace: string | null) {
    trackInteraction("marketplace_filter"); setMobileView("home"); changeCatalog({ ...catalog, page: 1, marketplace }, "replace", true);
  }
  async function submitEmail(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const input = form.querySelector<HTMLInputElement>("input[type='email']");
    const email = input?.value.trim() ?? "";
    if (!email) return;
    try {
      const response = await fetch("/api/newsletter", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
      const data = await response.json() as { ok: boolean; already?: boolean };
      if (!data.ok) throw new Error();
      showNotice(data.already ? "Você já estava na lista." : "Pronto! As próximas ofertas chegam primeiro para você."); form.reset();
    } catch { showNotice("Não deu para salvar agora. Tente de novo em instantes."); }
  }
  const changeSlide = (direction: number) => setCurrentSlide((slide) => (slide + direction + slideCount) % slideCount);
  function handleHeroImageClick(event: MouseEvent<HTMLAnchorElement>, productId: string) {
    if (carouselDragged.current) { event.preventDefault(); return; }
    trackInteraction("hero_detail_click", productId);
  }
  function finishCarouselGesture(clientX: number) {
    if (pointerStart.current === null) return;
    const distance = clientX - pointerStart.current;
    if (Math.abs(distance) > 48) { carouselDragged.current = true; changeSlide(distance > 0 ? -1 : 1); window.setTimeout(() => { carouselDragged.current = false; }, 0); }
    pointerStart.current = null;
  }

  return <main className="vitrine-page">
    <div className="signal-bar"><span>Bizu bom não espera.</span><span>Curadoria de ponta a ponta · links de afiliado</span></div>
    <header className="site-header">
      <a className="brand" href="#topo" aria-label="BizuMiner, início">
        <Image src="/brand/bizuminer-icon-light.svg" alt="" aria-hidden="true" width={32} height={32} priority className="brand-mark-img" />
        <span className="brand-name"><b>Bizu</b><i>Miner</i></span>
      </a>
      <SearchForm className="search-box header-search" id="busca-mobile" placeholder="Buscar oferta" query={query} disabled={isLoading} onQuery={setQuery} onSubmit={submitSearch} />
      <button className="nav-toggle" aria-expanded={navOpen} aria-controls="main-nav" onClick={() => setNavOpen((value) => !value)}>menu</button>
      <nav id="main-nav" className={navOpen ? "open" : ""} aria-label="Navegação principal"><a href="#achados" onClick={() => setNavOpen(false)}>Ofertas</a><a href="#criterios" onClick={() => setNavOpen(false)}>Como escolhemos</a><a href="#vendedores" onClick={() => setNavOpen(false)}>Para vendedores</a><a href="/minha-area" onClick={() => setNavOpen(false)}>Minha área</a>{isUserAdmin && <a href="/admin" onClick={() => setNavOpen(false)} style={{ color: "var(--blue-text, #1d4ed8)", fontWeight: 800 }}>⚡ Painel Admin</a>}</nav>
      <div className="header-actions">
        {isUserAdmin && (
          <a
            href="/admin"
            className="admin-badge-link"
            title="Acessar Painel do Administrador"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "4px",
              padding: "5px 10px",
              borderRadius: "6px",
              background: "var(--blue-soft, #eff6ff)",
              border: "1px solid var(--blue-line, #bfdbfe)",
              color: "var(--blue-text, #1d4ed8)",
              fontSize: "0.8rem",
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            ⚡ Admin
          </a>
        )}
        <ThemeToggle />
        <button className={showSaved ? "saved-button active" : "saved-button"} aria-pressed={showSaved} aria-label={`${favorites.length} produtos salvos, ver salvos`} onClick={toggleSavedView}><span>{showSaved ? "♥" : "♡"}</span><b>{favorites.length}</b></button>
      </div>
    </header>

    <section className="hero" id="topo" data-selection-version={editorialVersion ?? undefined} onFocusCapture={() => setCarouselFocused(true)} onBlurCapture={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) setCarouselFocused(false); }}>
      <div className="hero-carousel" role="region" aria-roledescription="carrossel" aria-label="Destaques BizuMiner" onMouseEnter={() => setCarouselHovered(true)} onMouseLeave={() => setCarouselHovered(false)} onPointerDown={(event) => { pointerStart.current = event.clientX; carouselDragged.current = false; }} onPointerUp={(event) => finishCarouselGesture(event.clientX)} onPointerCancel={() => { pointerStart.current = null; carouselDragged.current = false; }}>
        <div className="hero-track" style={{ transform: `translateX(-${currentSlide * 100}%)` }}><EditorialSlide products={heroProducts} hidden={currentSlide !== 0} />{heroProducts.map((product, index) => <ProductHeroSlide key={product.id} product={product} index={index} hidden={currentSlide !== index + 1} onImageClick={handleHeroImageClick} />)}</div>
      </div>
      <div className="carousel-bar"><div className="carousel-arrows"><button onClick={() => changeSlide(-1)} aria-label="Destaque anterior">←</button><button onClick={() => changeSlide(1)} aria-label="Próximo destaque">→</button></div><div className="carousel-progress" aria-hidden="true"><i key={currentSlide} className={carouselPaused ? "paused" : ""} /></div><span className="carousel-count">{String(currentSlide + 1).padStart(2, "0")} / {String(slideCount).padStart(2, "0")}</span><div className="carousel-dots">{Array.from({ length: slideCount }, (_, index) => <button key={index} className={currentSlide === index ? "active" : ""} aria-label={`Ir para o destaque ${index + 1}`} aria-current={currentSlide === index ? "true" : undefined} onClick={() => setCurrentSlide(index)} />)}</div></div>
      <div className="hero-tools"><div className="hero-tool-copy"><p className="eyebrow">Escolha com contexto</p><h1>Bons achados, sem perder tempo procurando.</h1><p className="hero-tool-lead">O BizuMiner acompanha preços e organiza as informações importantes para você decidir.</p><a href="#achados">ver ofertas <span>↓</span></a></div><SearchForm className="search-box hero-search" id="busca" placeholder="O que você está procurando?" query={query} disabled={isLoading} onQuery={setQuery} onSubmit={submitSearch} />{featuredProduct && <a className="hero-bizu" href={`/bizu/${featuredProduct.slug}`}><span><small>destaque selecionado</small>{featuredProduct.title}</span><b>↗</b></a>}</div>
    </section>

    <section className="filter-stack" aria-label="Filtrar ofertas">
      <div className="filter-nav-row">
        <CategoryList className="category-list" categories={categories} active={catalog.category} onChoose={chooseCategory} />
        <MarketplaceFilter className="mp-filter" active={catalog.marketplace} counts={marketplaceCounts} onChoose={chooseMarketplace} />
      </div>
      <div className="filter-control-row">
        <div className="filter-primary">
          <label className="freshness-control">preço verificado <select value={catalog.freshness} onChange={(event) => { trackInteraction("freshness_filter"); changeCatalog({ ...catalog, page: 1, freshness: event.target.value as FreshnessBand }, "replace", false); }}>{freshnessOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
          <div className="price-filters" aria-label="Faixa de preço">{priceFilters.map((item) => <button key={item.value} className={catalog.priceBand === item.value ? "active" : ""} onClick={() => { trackInteraction("price_filter"); changeCatalog({ ...catalog, page: 1, priceBand: item.value }, "replace", false); }}>{item.label}</button>)}</div>
          <label className="sort-control">ordenar por <select value={catalog.sort} onChange={(event) => { trackInteraction("sort"); changeCatalog({ ...catalog, page: 1, sort: event.target.value as DealSort }, "replace", false); }}>{sortOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
        </div>
        <div className="filter-active-pills">
          {catalog.minRating !== null && <button className="pill" onClick={() => { trackInteraction("filter_remove"); changeCatalog({ ...catalog, page: 1, minRating: null }, "replace", false); }}>★★{catalog.minRating}+ ✕</button>}
          {catalog.minDiscount !== null && <button className="pill" onClick={() => { trackInteraction("filter_remove"); changeCatalog({ ...catalog, page: 1, minDiscount: null }, "replace", false); }}>{catalog.minDiscount}%+ ✕</button>}
          {catalog.lowestOnly && <button className="pill" onClick={() => { trackInteraction("filter_remove"); changeCatalog({ ...catalog, page: 1, lowestOnly: false }, "replace", false); }}>menor preço ✓ ✕</button>}
          {catalog.hasHistory && <button className="pill" onClick={() => { trackInteraction("filter_remove"); changeCatalog({ ...catalog, page: 1, hasHistory: false }, "replace", false); }}>com histórico ✕</button>}
          {(catalog.minRating !== null || catalog.minDiscount !== null || catalog.lowestOnly || catalog.hasHistory) && <button className="pill pill-clear" onClick={() => { trackInteraction("filter_clear_secondary"); changeCatalog({ ...catalog, page: 1, minRating: null, minDiscount: null, lowestOnly: false, hasHistory: false }, "replace", false); }}>limpar</button>}
        </div>
        <button className="filter-expand" aria-label="Mais filtros" onClick={() => setMobileView(mobileView === "filters" ? "home" : "filters")}>+ filtros</button>
      </div>
    </section>

    <section className="finds" id="achados" aria-busy={isLoading}>
      <div className="section-heading"><div><p className="eyebrow">{showSaved ? "Seus salvos · viajam com você" : `Ofertas monitoradas · ${dateLabel}`}</p><h2>{showSaved ? "Seus salvos" : "Catálogo de ofertas"}</h2><p className="mobile-result-count">{isLoading ? "atualizando…" : `${total} ofertas monitoradas · ${dateLabel}`}</p></div><button className="section-help" type="button" aria-label="Como ler os preços e o desconto" onClick={() => setMobileView("guide")}>?</button><p className="result-count">{isLoading ? "atualizando…" : showSaved ? `${savedProducts.length} salvos` : `Mostrando ${visibleFrom}–${visibleTo} de ${total} ofertas`}</p></div>
      {!showSaved && catalog.category === null && catalog.priceBand === "all" && !catalog.search && <p className="catalog-intro">{catalogGuide}</p>}
      {loadError && <p className="catalog-error" role="alert">{loadError} <button onClick={() => void fetchDeals(catalog, false)}>tentar de novo</button></p>}
      <div className="desktop-catalog">{shownProducts.length ? <><div className="product-grid">{shownProducts.map((product) => <ProductCard key={product.id} product={product} favorite={favorites.includes(product.id)} onFavorite={toggleFavorite} editorialRationale={editorialRationales.get(product.id)} editorialPurchaseContents={editorialContents.get(product.id)} />)}</div>{!showSaved && totalPages > 1 && <CatalogPagination current={catalog.page} total={totalPages} disabled={isLoading} onChange={changePage} />}</> : !isLoading && <EmptyState onClear={clearFilters} saved={showSaved} />}</div>
      <div className="mobile-catalog"><div className="mobile-catalog-toolbar"><CategoryList className="category-list toolbar-chips" categories={categories} active={catalog.category} onChoose={chooseCategory} /><button className="toolbar-filters" aria-label={`Filtros${(catalog.priceBand !== "all" || catalog.sort !== "signal" || catalog.minRating !== null || catalog.minDiscount !== null || catalog.lowestOnly || catalog.hasHistory || catalog.freshness !== "2d") ? " (ativos)" : ""}`} onClick={() => setMobileView("filters")}><span aria-hidden="true">⚙</span>{(catalog.priceBand !== "all" || catalog.sort !== "signal" || catalog.minRating !== null || catalog.minDiscount !== null || catalog.lowestOnly || catalog.hasHistory || catalog.freshness !== "2d") && <em aria-hidden="true" />}</button></div>{mobileProducts.length ? <div className="mobile-product-grid">{mobileProducts.map((product, index) => <Fragment key={product.id}><ProductCard product={product} favorite={favorites.includes(product.id)} onFavorite={toggleFavorite} editorialRationale={editorialRationales.get(product.id)} editorialPurchaseContents={editorialContents.get(product.id)} featured={index === 0} />{index === 5 && discoveryCategories.length > 0 && <DiscoveryBreak categories={discoveryCategories} onChoose={chooseCategory} />}</Fragment>)}</div> : !isLoading && <EmptyState onClear={clearFilters} />}{mobileHasMore && <button className="mobile-load-more" type="button" disabled={isLoading} onClick={() => void loadMore()}>{isLoading ? "carregando…" : "carregar mais 24"}<span>{mobileProducts.length} de {total} ofertas</span></button>}</div>
    </section>

    <section className="price-radar" aria-label="Como avaliamos os preços"><div><p className="eyebrow">Histórico BizuMiner</p><h2>Desconto chama atenção.<br /><em>Histórico</em> ajuda a decidir.</h2></div><div className="radar-note"><span className="radar-orbit"><i>R$</i></span><p>Registramos o preço em cada captura. Enquanto o acompanhamento ainda é curto, mostramos exatamente quantos registros existem — sem transformar pouca informação em certeza.</p></div></section>
    <section className="criteria" id="criterios"><div className="criteria-intro"><p className="eyebrow">Da busca à recomendação</p><h2>Todo bizu passa por camadas.</h2><p>O BizuMiner combina automação com critérios claros. Antes de uma oferta chegar até você, organizamos produto, preço e evidências do anúncio.</p></div><ol className="criteria-list"><li><span>01</span><div><h3>Encontrar produtos úteis</h3><p>Selecionamos itens com função clara e potencial de melhorar a rotina.</p></div></li><li><span>02</span><div><h3>Conferir preço e histórico</h3><p>Comparamos o preço atual com os registros que já coletamos, sem prometer o que os dados ainda não provam.</p></div></li><li><span>03</span><div><h3>Apresentar com contexto</h3><p>Preço, avaliação, vendas informadas e link de afiliado aparecem com a fonte identificada.</p></div></li></ol></section>
    <section className="seller-callout" id="vendedores"><div className="seller-stamp">TEM UM<br />BIZU?</div><div><p className="eyebrow">Quer apresentar seu produto?</p><h2>Entre no nosso processo de seleção.</h2></div><div className="seller-copy"><p>Automatizar ofertas é fácil. Conquistar público qualificado é BizuMiner. Marcas e vendedores podem sugerir produtos; a curadoria continua independente.</p><a href="mailto:oi@bizuminer.com.br?subject=Quero%20mandar%20um%20bizu">enviar um produto <span>↗</span></a></div></section>
    <section className="newsletter"><div><span className="newsletter-icon"><Image src="/brand/bizuminer-icon-square-blue.svg" alt="" width={44} height={44} className="rounded-xl" /></span></div><div><p className="eyebrow">Bizus antes de todo mundo</p><h2>As próximas ofertas chegam na sua caixa.</h2></div><form onSubmit={submitEmail}><label className="sr-only" htmlFor="email">Seu melhor e-mail</label><input id="email" type="email" required placeholder="seu melhor e-mail" /><button type="submit">quero receber <span>→</span></button></form></section>
    <footer><a className="brand footer-brand" href="#topo" aria-label="BizuMiner, início"><Image src="/brand/bizuminer-icon-dark.svg" alt="" aria-hidden="true" width={30} height={30} className="brand-mark-img" /><span className="brand-name"><b>Bizu</b><i>Miner</i></span></a><p>A gente acompanha preços para trazer ofertas que valem a sua atenção.</p><div><a href="#criterios">transparência</a><a href="#vendedores">vendedores</a><a href="mailto:oi@bizuminer.com.br">contato</a></div><small>Alguns links são de afiliado. Podemos receber comissão sem custo adicional para você.</small></footer>

    {mobileView === "categories" && <MobilePanel view="categories" title="Categorias" onClose={() => setMobileView("home")}><p className="mobile-panel-intro">Explore por interesse e volte ao feed quando quiser.</p><label className="mobile-panel-search"><span aria-hidden="true">⌕</span><span className="sr-only">Buscar categoria</span><input value={categoryQuery} onChange={(event) => setCategoryQuery(event.target.value)} placeholder="Buscar uma categoria" /></label><div className="mobile-category-cards"><button onClick={() => chooseCategory(null)}><b>Todas as ofertas</b><span>Ver o catálogo completo</span><i>→</i></button>{filteredCategories.map((item) => <button key={item} onClick={() => chooseCategory(item)}><b>{item}</b><span>Ver ofertas monitoradas</span><i>→</i></button>)}</div></MobilePanel>}
    {mobileView === "saved" && <MobilePanel view="saved" title="Seus salvos" meta={`${favorites.length}`} onClose={() => setMobileView("home")}><p className="mobile-panel-intro">Os seus salvos ficam na conta: na <a href="/minha-area">minha área</a> dá para acompanhar o preço de cada um.</p>{savedProducts.length ? <div className="mobile-product-grid mobile-saved-grid">{savedProducts.map((product) => <ProductCard key={product.id} product={product} favorite onFavorite={toggleFavorite} editorialRationale={editorialRationales.get(product.id)} editorialPurchaseContents={editorialContents.get(product.id)} />)}</div> : <EmptyState onClear={() => setMobileView("home")} saved />}</MobilePanel>}
    {mobileView === "filters" && <MobilePanel view="filters" title="Filtros refinados" onClose={() => setMobileView("home")}><div className="mobile-filter-group"><h3>Faixa de preço</h3><div>{priceFilters.map((item) => <button key={item.value} className={catalog.priceBand === item.value ? "active" : ""} onClick={() => { trackInteraction("price_filter"); changeCatalog({ ...catalog, page: 1, priceBand: item.value }, "replace", false); }}>{item.label}</button>)}</div></div><div className="mobile-filter-group"><h3>Frescura do preço</h3><div>{freshnessOptions.map((item) => <button key={item.value} className={catalog.freshness === item.value ? "active" : ""} onClick={() => { trackInteraction("freshness_filter"); changeCatalog({ ...catalog, page: 1, freshness: item.value }, "replace", false); }}>{item.label}</button>)}</div></div><div className="mobile-filter-group"><h3>Avaliação mínima</h3><div>{ratingOptions.map((item) => <button key={item.value} className={catalog.minRating === item.value ? "active" : ""} onClick={() => { trackInteraction("rating_filter"); changeCatalog({ ...catalog, page: 1, minRating: catalog.minRating === item.value ? null : item.value }, "replace", false); }}>{item.label}</button>)}</div></div><div className="mobile-filter-group"><h3>Desconto informado</h3><div>{discountOptions.map((item) => <button key={item.value} className={catalog.minDiscount === item.value ? "active" : ""} onClick={() => { trackInteraction("discount_filter"); changeCatalog({ ...catalog, page: 1, minDiscount: catalog.minDiscount === item.value ? null : item.value }, "replace", false); }}>{item.label}</button>)}</div></div><div className="mobile-filter-group"><h3>Confiança BizuMiner</h3><div className="mobile-toggles"><button className={catalog.lowestOnly ? "active" : ""} onClick={() => { trackInteraction("confidence_filter"); changeCatalog({ ...catalog, page: 1, lowestOnly: !catalog.lowestOnly }, "replace", false); }}>menor preço verificado</button><button className={catalog.hasHistory ? "active" : ""} onClick={() => { trackInteraction("confidence_filter"); changeCatalog({ ...catalog, page: 1, hasHistory: !catalog.hasHistory }, "replace", false); }}>com histórico (3+ obs.)</button></div></div><label className="mobile-sort-control"><span>Ordenar por</span><select value={catalog.sort} onChange={(event) => { trackInteraction("sort"); changeCatalog({ ...catalog, page: 1, sort: event.target.value as DealSort }, "replace", false); }}>{sortOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label><button className="mobile-clear-filters" onClick={clearFilters}>limpar filtros</button></MobilePanel>}
    {mobileView === "guide" && <MobilePanel view="guide" title="Como ler os preços" onClose={() => setMobileView("home")}><p className="mobile-panel-intro">{catalogGuide}</p><ul className="guide-legend"><li><span className="signal-badge verified">menor preço que já vimos</span><p>O preço atual é o menor observado para a mesma configuração confirmada, com pelo menos 3 registros distribuídos em 7 dias. Sem identificar a configuração, mostramos apenas o histórico do anúncio.</p></li><li><span className="signal-badge drop">caiu 12% desde o menor que vimos</span><p>O preço caiu abaixo do menor valor registrado para a mesma configuração confirmada. A comparação usa nosso histórico e não afirma que está barato no mercado.</p></li><li><span className="signal-badge unproven">ainda sem histórico</span><p>Vimos este produto uma vez só. Não há com o que comparar, então trate o desconto do anúncio com cautela extra.</p></li><li><span className="guide-discount">−38% no anúncio</span><p>Desconto informado pelo próprio anúncio no Mercado Livre — é alegação do vendedor, não cálculo nosso.</p></li><li><span className="guide-silence">sem selo</span><p>O preço não se moveu em relação ao que já tínhamos registrado. Silêncio aqui quer dizer que não há novidade — e é por isso que, quando um selo aparece, ele merece atenção.</p></li></ul></MobilePanel>}
    {mobileView === "menu" && <MobilePanel view="menu" title="Menu" onClose={() => setMobileView("home")}><div className="mobile-theme-row"><div><b>Aparência</b><span>Claro ou escuro, do seu jeito</span></div><ThemeToggle className="theme-toggle-wide" withLabel /></div><nav className="mobile-menu-links" aria-label="Menu mobile"><a href="/minha-area"><span>Minha área</span><b>→</b></a>{isUserAdmin && <a href="/admin"><span>⚡ Painel Admin</span><b>→</b></a>}<a href="#achados" onClick={() => setMobileView("home")}><span>Ofertas</span><b>→</b></a><a href="#criterios" onClick={() => setMobileView("home")}><span>Como escolhemos</span><b>→</b></a><a href="#vendedores" onClick={() => setMobileView("home")}><span>Para vendedores</span><b>→</b></a><a href="mailto:oi@bizuminer.com.br"><span>Contato</span><b>↗</b></a></nav></MobilePanel>}

    <nav className="mobile-bottom-nav" aria-label="Navegação mobile"><button className={mobileView === "home" ? "active" : ""} aria-current={mobileView === "home" ? "page" : undefined} onClick={() => { setMobileView("home"); document.querySelector("#topo")?.scrollIntoView({ behavior: "smooth" }); }}><span aria-hidden="true">⌂</span><b>Início</b></button><button className={mobileView === "categories" ? "active" : ""} aria-current={mobileView === "categories" ? "page" : undefined} onClick={() => setMobileView("categories")}><span aria-hidden="true">▦</span><b>Categorias</b></button><button className={mobileView === "saved" ? "active" : ""} aria-current={mobileView === "saved" ? "page" : undefined} onClick={() => setMobileView("saved")}><span aria-hidden="true">♡</span><b>Salvos</b>{favorites.length > 0 && <i>{favorites.length}</i>}</button><button className={mobileView === "menu" ? "active" : ""} aria-current={mobileView === "menu" ? "page" : undefined} onClick={() => setMobileView("menu")}><span aria-hidden="true">☰</span><b>Menu</b></button></nav>
    <div className={notice ? "toast visible" : "toast"} role="status" aria-live="polite">{notice}</div>
  </main>;
}

function MobilePanel({ view, title, meta, onClose, children }: { view: Exclude<MobileView, "home">; title: string; meta?: string; onClose: () => void; children: React.ReactNode }) {
  return <section className="mobile-view-panel" aria-labelledby={`mobile-${view}-title`}><header><button onClick={onClose} aria-label={`Fechar ${title}`}>←</button><h2 id={`mobile-${view}-title`} tabIndex={-1}>{title}</h2>{meta ? <span>{meta}</span> : <i />}</header><div className="mobile-panel-content">{children}</div></section>;
}

function DiscoveryBreak({ categories, onChoose }: { categories: string[]; onChoose: (category: string) => void }) {
  return <aside className="discovery-break"><p>Quer mudar o rumo?</p><div>{categories.map((category) => <button key={category} onClick={() => onChoose(category)}>{category} <span>→</span></button>)}</div></aside>;
}

function EmptyState({ onClear, saved = false }: { onClear: () => void; saved?: boolean }) {
  return <div className="empty-state"><span>{saved ? "♡" : "◇"}</span><h3>{saved ? "Nenhum produto salvo." : "Nenhum produto encontrado."}</h3><p>{saved ? "Toque no coração de um produto para guardá-lo aqui." : "Tente outro termo ou limpe os filtros."}</p><button onClick={onClear}>{saved ? "ver ofertas" : "limpar filtros"}</button></div>;
}

function CatalogPagination({ current, total, disabled, onChange }: { current: number; total: number; disabled: boolean; onChange: (page: number) => void }) {
  const items = paginationItems(current, total);
  return <nav className="catalog-pagination" aria-label="Paginação das ofertas"><button className="pagination-direction" type="button" disabled={disabled || current === 1} onClick={() => onChange(current - 1)}><span aria-hidden="true">←</span><b>anterior</b></button><div className="pagination-numbers">{items.map((item) => typeof item === "number" ? <button key={item} type="button" className={item === current ? "active" : ""} aria-current={item === current ? "page" : undefined} aria-label={`Ir para a página ${item}`} disabled={disabled} onClick={() => onChange(item)}>{item}</button> : <span key={item} aria-hidden="true">…</span>)}</div><span className="pagination-mobile-status" aria-live="polite">Página {current} de {total}</span><button className="pagination-direction next" type="button" disabled={disabled || current === total} onClick={() => onChange(current + 1)}><b>próxima</b><span aria-hidden="true">→</span></button></nav>;
}

function ProductCard({ product, favorite, onFavorite, editorialRationale, editorialPurchaseContents, featured = false }: { product: VitrineProduct; favorite: boolean; onFavorite: (product: VitrineProduct) => void; editorialRationale?: string; editorialPurchaseContents?: string; featured?: boolean }) {
  const fresh = priceFreshness(product.evidenceObservedAt);
  const highlight = fresh === "current" ? priceHighlight(historyInput(product)) : null;
  const discountPct = fresh === "current" ? discountPercentOf(product) : null;
  const freshness = fresh === "current" ? freshnessLabel(product.evidenceObservedAt) : null;
  const seen = fresh === "stale" ? seenAgo(product.evidenceObservedAt) : null;
  const marketplaceDefinition = marketplaceDef(product.marketplace);
  const marketplaceLabel = marketplaceDefinition?.label ?? product.marketplace;
  const ctaLabel = marketplaceDefinition?.ctaLabel ?? `ver na ${marketplaceLabel}`;
  const marketplaceLogo = marketplaceDefinition?.logo;
  return <article className={`product-card${featured ? " mobile-featured-card" : ""}`}><div className="product-image"><a href={`/bizu/${product.slug}`} aria-label={`Abrir detalhes de ${product.title}`}>{product.imageUrl ? <Image src={product.imageUrl} alt={product.title} fill sizes={featured ? "(max-width: 820px) calc(100vw - 32px), 25vw" : "(max-width: 560px) calc((100vw - 44px) / 2), (max-width: 1100px) 33vw, 25vw"} /> : <div className="image-placeholder"><Image src="/brand/bizuminer-icon-light.svg" alt="BizuMiner" width={32} height={32} /></div>}<MarketplaceIcon logo={marketplaceLogo} className="origin-icon" /></a>{discountPct !== null && <span className="discount"><b>−{discountPct}%</b><i> no anúncio</i></span>}<button className={favorite ? "favorite active" : "favorite"} aria-label={`${favorite ? "Remover" : "Salvar"} ${product.title}`} aria-pressed={favorite} onClick={() => onFavorite(product)}>{favorite ? "♥" : "♡"}</button></div><div className={highlight ? "product-meta" : "product-meta quiet"}>{highlight && <span className={`signal-badge ${highlight.tone}`}>{highlight.label}</span>}</div><h3><a href={`/bizu/${product.slug}`}>{product.title}</a></h3><MarketplaceEvidence product={product} />{editorialRationale && <p className="product-editorial-rationale">{editorialRationale}</p>}{editorialPurchaseContents && <p className="product-editorial-contents"><b>O que vem:</b> {editorialPurchaseContents}</p>}<p className="product-blurb"><b>Histórico do preço:</b> {priceNarrative(historyInput(product), brl)}</p><div className="product-price"><div>{fresh === "current" ? <><small>{product.originalPriceCents && product.originalPriceCents > product.priceCents ? brl(product.originalPriceCents) : ""}</small><strong>{brl(product.priceCents)}</strong>{freshness && <em>{freshness}</em>}</> : <span className="stale-price"><strong>{brl(product.priceCents)}</strong><em>última vez visto {seen ?? "há algum tempo"}</em></span>}</div><a href={`/go/${product.slug}`} target="_blank" rel="noreferrer sponsored" onClick={() => trackInteraction("outbound_click", product.id)}><MarketplaceIcon logo={marketplaceLogo} className="cta-icon" /><span>{ctaLabel}</span><b>↗</b></a></div><CopyProductLink slug={product.slug} title={product.title} /></article>;
}
