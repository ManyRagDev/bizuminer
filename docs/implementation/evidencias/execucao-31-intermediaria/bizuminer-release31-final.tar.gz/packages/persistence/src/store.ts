/**
 * Contrato de persistência da captura.
 *
 * A interface mantém ingestão e testes independentes da infraestrutura:
 * `InMemoryStore` cobre o comportamento local e `PostgresStore` persiste no
 * Supabase/Postgres sem acoplar o serviço de ingestão ao driver SQL.
 */

import { classifyActivity } from "./activity.ts";
import type { ActivityCounts } from "./activity.ts";
import type { ProductFamilyInfo } from "./product-family.ts";
import type { OfferEvidence } from "../../capture/src/types.ts";

export interface ProductRecord {
  readonly id: string;
  readonly tenantId: string;
  readonly marketplace: string;
  readonly externalId: string;
  readonly title: string;
  readonly productUrl: string;
  readonly imageUrl?: string;
  readonly category?: string;
  readonly family?: ProductFamilyInfo;
  readonly lastPriceCents: number;
  readonly firstSeenAt: Date;
  readonly lastSeenAt: Date;
  readonly lastCaptureRunId?: string;
}

export interface PriceObservationRecord {
  readonly captureRunId: string;
  readonly productId: string;
  readonly priceCents: number;
  readonly originalPriceCents?: number;
  readonly claimedDiscountRate?: number;
  readonly ratingStar?: number;
  readonly salesLabel?: string;
  /** Limite inferior aproximado derivado do rótulo do marketplace. */
  readonly salesCount?: number;
  readonly offerEvidence?: OfferEvidence;
  readonly observedAt: Date;
  readonly titleSnapshot: string;
  readonly productUrlSnapshot: string;
  readonly imageUrlSnapshot?: string;
  readonly categorySnapshot?: string;
}

export interface UpsertResult {
  readonly product: ProductRecord;
  readonly isNew: boolean;
  /** Preço anterior quando houve mudança; ausente na primeira observação. */
  readonly previousPriceCents?: number;
}

export interface CaptureRunRecord {
  readonly id: string;
  readonly tenantId: string;
  readonly marketplace: string;
  readonly startedAt: Date;
  readonly finishedAt?: Date;
  readonly status: "running" | "ok" | "error";
  readonly itemsCaptured: number;
  readonly itemsNew: number;
  readonly priceChanges: number;
  readonly error?: string;
  readonly collectorRunId: string;
  readonly parameters: Readonly<Record<string, string | number | boolean | null | undefined>>;
}

export type StartCaptureRunInput = Pick<CaptureRunRecord, "tenantId" | "marketplace" | "startedAt" | "collectorRunId" | "parameters">;
export interface FinishCaptureRunInput {
  readonly tenantId?: string; // Explicit scope for callers; legacy house callers remain compatible.
  readonly finishedAt: Date;
  readonly status: "ok" | "error";
  readonly itemsCaptured: number;
  readonly itemsNew: number;
  readonly priceChanges: number;
  readonly error?: string;
  /** Métricas conhecidas apenas ao fim, mescladas ao JSON de auditoria. */
  readonly parameterPatch?: Readonly<Record<string, string | number | boolean | null | undefined>>;
}

export interface OfferStore {
  /**
   * Consulta em lote quais anúncios já pertencem ao catálogo.
   * O gate de descoberta usa isto para nunca bloquear a reobservação de preço
   * de um produto conhecido, mesmo quando a família dele está saturada.
   */
  findExistingExternalIds(
    tenantId: string,
    marketplace: string,
    externalIds: readonly string[],
  ): Promise<ReadonlySet<string>>;

  upsertProductWithObservation(input: {
    captureRunId: string;
    tenantId: string;
    marketplace: string;
    externalId: string;
    title: string;
    productUrl: string;
    imageUrl?: string;
    category?: string;
    family?: ProductFamilyInfo;
    priceCents: number;
    originalPriceCents?: number;
    claimedDiscountRate?: number;
    ratingStar?: number;
    salesLabel?: string;
    salesCount?: number;
    offerEvidence?: OfferEvidence;
    observedAt: Date;
  }): Promise<UpsertResult>;

  startCaptureRun(run: StartCaptureRunInput): Promise<string>;
  finishCaptureRun(runId: string, run: FinishCaptureRunInput): Promise<void>;

  /** Menor e maior preço observados de um produto — curadoria da Phase 3. */
  priceRange(productId: string): Promise<
    { minCents: number; maxCents: number; observations: number } | null
  >;

  /** Última observação — desconto declarado para ranking na primeira varredura. */
  latestObservation(productId: string): Promise<PriceObservationRecord | null>;

  /**
   * Resumo do estado de vida derivado (ativo/recente/dormente) do catálogo.
   * `currentRunId` = rodagem que acabou de rodar; produtos vistos nela são
   * ativos. Nunca grava estado — é leitura pura (ver activity.ts).
   */
  productActivity(tenantId: string, currentRunId: string | null, now?: Date): Promise<ActivityCounts>;
}

export type { ActivityCounts } from "./activity.ts";

/** Implementação em memória — testes, CLI local e bootstrap sem banco. */
export class InMemoryStore implements OfferStore {
  private readonly products = new Map<string, ProductRecord>();
  private readonly observations = new Map<string, PriceObservationRecord[]>();
  private readonly runs = new Map<string, CaptureRunRecord>();
  private seq = 0;

  async upsertProductWithObservation(input: {
    captureRunId: string;
    tenantId: string;
    marketplace: string;
    externalId: string;
    title: string;
    productUrl: string;
    imageUrl?: string;
    category?: string;
    family?: ProductFamilyInfo;
    priceCents: number;
    originalPriceCents?: number;
    claimedDiscountRate?: number;
    ratingStar?: number;
    salesLabel?: string;
    salesCount?: number;
    offerEvidence?: OfferEvidence;
    observedAt: Date;
  }): Promise<UpsertResult> {
    const key = `${input.tenantId}|${input.marketplace}|${input.externalId}`;
    const existing = this.products.get(key);

    let product: ProductRecord;
    let previousPriceCents: number | undefined;

    if (existing) {
      previousPriceCents = existing.lastPriceCents;
      product = {
        ...existing,
        title: input.title,
        productUrl: input.productUrl,
        imageUrl: input.imageUrl ?? existing.imageUrl,
        category: input.category ?? existing.category,
        family: input.family ?? existing.family,
        lastPriceCents: input.priceCents,
        lastSeenAt: input.observedAt,
        lastCaptureRunId: input.captureRunId,
      };
      this.products.set(key, product);
    } else {
      product = {
        id: `p${++this.seq}`,
        tenantId: input.tenantId,
        marketplace: input.marketplace,
        externalId: input.externalId,
        title: input.title,
        productUrl: input.productUrl,
        imageUrl: input.imageUrl,
        category: input.category,
        family: input.family,
        lastPriceCents: input.priceCents,
        firstSeenAt: input.observedAt,
        lastSeenAt: input.observedAt,
        lastCaptureRunId: input.captureRunId,
      };
      this.products.set(key, product);
    }

    const observation: PriceObservationRecord = {
        captureRunId: input.captureRunId,
        productId: product.id,
        priceCents: input.priceCents,
        originalPriceCents: input.originalPriceCents,
        claimedDiscountRate: input.claimedDiscountRate,
        ratingStar: input.ratingStar,
        salesLabel: input.salesLabel,
        salesCount: input.salesCount,
        offerEvidence: input.offerEvidence,
        observedAt: input.observedAt,
        titleSnapshot: input.title,
        productUrlSnapshot: input.productUrl,
        imageUrlSnapshot: input.imageUrl,
        categorySnapshot: input.category,
    };
    const observations = this.observations.get(product.id) ?? [];
    const duplicate = observations.findIndex((item) => item.captureRunId === input.captureRunId);
    if (duplicate >= 0) {
      const previous = observations[duplicate]!;
      // Uma repetição incompleta da mesma oferta não apaga a evidência.
      // Oferta alterada não herda configuração nem pacote de outra captura.
      observations[duplicate] = {
        ...observation,
        offerEvidence: observation.offerEvidence ?? (
          previous.titleSnapshot === observation.titleSnapshot &&
          previous.productUrlSnapshot === observation.productUrlSnapshot &&
          previous.imageUrlSnapshot === observation.imageUrlSnapshot &&
          previous.categorySnapshot === observation.categorySnapshot &&
          previous.priceCents === observation.priceCents
            ? previous.offerEvidence
            : undefined
        ),
      };
    }
    else observations.push(observation);
    this.observations.set(product.id, observations);

    return {
      product,
      isNew: !existing,
      previousPriceCents: existing ? previousPriceCents : undefined,
    };
  }

  async startCaptureRun(run: StartCaptureRunInput): Promise<string> {
    const id = `r${++this.seq}`;
    this.runs.set(id, { id, ...run, status: "running", itemsCaptured: 0, itemsNew: 0, priceChanges: 0 });
    return id;
  }

  async finishCaptureRun(runId: string, run: FinishCaptureRunInput): Promise<void> {
    const existing = this.runs.get(runId);
    if (!existing) throw new Error(`capture_run inexistente: ${runId}`);
    const { parameterPatch, ...finished } = run;
    this.runs.set(runId, {
      ...existing,
      ...finished,
      parameters: { ...existing.parameters, ...(parameterPatch ?? {}) },
    });
  }

  async findExistingExternalIds(
    tenantId: string,
    marketplace: string,
    externalIds: readonly string[],
  ): Promise<ReadonlySet<string>> {
    const wanted = new Set(externalIds);
    const found = new Set<string>();
    for (const product of this.products.values()) {
      if (
        product.tenantId === tenantId &&
        product.marketplace === marketplace &&
        wanted.has(product.externalId)
      ) {
        found.add(product.externalId);
      }
    }
    return found;
  }

  async priceRange(productId: string) {
    const obs = this.observations.get(productId);
    if (!obs || obs.length === 0) return null;
    const prices = obs.map((o) => o.priceCents);
    return {
      minCents: Math.min(...prices),
      maxCents: Math.max(...prices),
      observations: obs.length,
    };
  }

  async latestObservation(productId: string): Promise<PriceObservationRecord | null> {
    const obs = this.observations.get(productId);
    return obs && obs.length > 0 ? obs[obs.length - 1]! : null;
  }

  async productActivity(
    tenantId: string,
    currentRunId: string | null,
    now: Date = new Date(),
  ): Promise<ActivityCounts> {
    const counts = { ativo: 0, recente: 0, dormente: 0 };
    for (const product of this.products.values()) {
      if (product.tenantId !== tenantId) continue;
      const level = classifyActivity({
        seenInCurrentRun: currentRunId != null && product.lastCaptureRunId === currentRunId,
        daysSinceLastSeen: Math.max(0, Math.floor((now.getTime() - product.lastSeenAt.getTime()) / 86_400_000)),
      });
      counts[level] += 1;
    }
    return counts;
  }

  /** Exposto para inspeção em CLI/teste. */
  get allRuns(): readonly CaptureRunRecord[] {
    return [...this.runs.values()];
  }

  get allProducts(): readonly ProductRecord[] {
    return [...this.products.values()];
  }
}
