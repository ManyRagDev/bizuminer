/**
 * Extração de contadores e metadados de Oferta Relâmpago do Mercado Livre.
 * Suporta o DOM do card (.poly-countdown__block com dígitos estáticos),
 * o HTML cru do card clicado e o JSON de hidratação da página (period_end).
 */

export interface MlCountdownResult {
  promotionType: "lightning";
  remainingSeconds: number;
  promotionEndsAt: string;
}

/**
 * Lê os blocos .poly-countdown__block dentro de um elemento DOM.
 * No Mercado Livre, o contador é formatado como 3 blocos (HH : MM : SS)
 * ou eventualmente 2 blocos (MM : SS).
 */
export function extractMlCountdownFromElement(
  container: Element,
  capturedAtMs = Date.now(),
): MlCountdownResult | null {
  const cd = container.querySelector(
    ".poly-component__countdown, .poly-component__highlight-countdown, [class*='countdown']",
  );
  const root = cd ?? container;
  const blocks = Array.from(root.querySelectorAll(".poly-countdown__block"));
  if (blocks.length !== 2 && blocks.length !== 3) {
    return null;
  }

  const numbers: number[] = [];
  for (const block of blocks) {
    const digits = Array.from(
      block.querySelectorAll(".poly-countdown__digit--static, .poly-countdown__digit"),
    )
      .map((d) => (d.textContent || "").trim())
      .filter((t) => /^\d$/.test(t))
      .join("");
    if (digits) {
      const val = parseInt(digits, 10);
      if (Number.isFinite(val)) {
        numbers.push(val);
      }
    }
  }

  let sec = 0;
  if (numbers.length === 3) {
    const [h, m, s] = numbers;
    sec = (h ?? 0) * 3600 + (m ?? 0) * 60 + (s ?? 0);
  } else if (numbers.length === 2) {
    const [m, s] = numbers;
    sec = (m ?? 0) * 60 + (s ?? 0);
  }

  if (sec <= 0) return null;

  return {
    promotionType: "lightning",
    remainingSeconds: sec,
    promotionEndsAt: new Date(capturedAtMs + sec * 1000).toISOString(),
  };
}

/**
 * Extrai o countdown de um fragmento de string HTML (usado no card-extractor).
 */
export function extractMlCountdownFromHtml(
  html: string,
  capturedAtMs = Date.now(),
): MlCountdownResult | null {
  const cdIdx = html.indexOf("poly-component__countdown");
  const blockIdx = html.indexOf("poly-countdown__block");
  if (cdIdx === -1 && blockIdx === -1) return null;
  const startIdx = cdIdx !== -1 ? cdIdx : blockIdx;
  const slice = html.slice(startIdx, startIdx + 2000);

  const blockMatches = [
    ...slice.matchAll(
      /class="[^"]*poly-countdown__block[^"]*"[\s\S]*?(?=(?:class="[^"]*poly-countdown__block"|<span class="poly-countdown__separator"|<\/div>\s*<\/div>\s*<\/div>|$))/g,
    ),
  ];
  if (blockMatches.length !== 2 && blockMatches.length !== 3) return null;

  const digitRegex = /class="[^"]*poly-countdown__digit[^"]*"[^>]*>\s*(\d)\s*<\/span>/g;
  const numbers: number[] = [];
  for (const b of blockMatches) {
    const digits = [...b[0].matchAll(digitRegex)].map((m) => m[1]).join("");
    if (digits) {
      const val = parseInt(digits, 10);
      if (Number.isFinite(val)) numbers.push(val);
    }
  }

  let sec = 0;
  if (numbers.length === 3) {
    const [h, m, s] = numbers;
    sec = (h ?? 0) * 3600 + (m ?? 0) * 60 + (s ?? 0);
  } else if (numbers.length === 2) {
    const [m, s] = numbers;
    sec = (m ?? 0) * 60 + (s ?? 0);
  }

  if (sec <= 0) return null;

  return {
    promotionType: "lightning",
    remainingSeconds: sec,
    promotionEndsAt: new Date(capturedAtMs + sec * 1000).toISOString(),
  };
}

/**
 * Busca o period_end no script JSON de hidratação da página do Mercado Livre
 * para o produto específico (MLB...).
 */
export function findMlScriptPeriodEnd(
  doc: Document,
  externalId: string,
  capturedAtMs = Date.now(),
): MlCountdownResult | null {
  if (!externalId || typeof doc.querySelectorAll !== "function") return null;
  const scripts = Array.from(doc.querySelectorAll("script"));
  for (const s of scripts) {
    const text = s.textContent || "";
    if (!text.includes(externalId) || !text.includes("period_end")) continue;

    // Localiza o bloco JSON do card que contém o externalId
    const idIdx = text.indexOf(externalId);
    if (idIdx === -1) continue;
    const windowSlice = text.slice(Math.max(0, idIdx - 500), Math.min(text.length, idIdx + 1500));
    const m = /"period_end"\s*:\s*"([^"]+)"/.exec(windowSlice);
    if (m?.[1]) {
      const endsMs = Date.parse(m[1]);
      if (Number.isFinite(endsMs) && endsMs > capturedAtMs) {
        return {
          promotionType: "lightning",
          remainingSeconds: Math.round((endsMs - capturedAtMs) / 1000),
          promotionEndsAt: new Date(endsMs).toISOString(),
        };
      }
    }
  }
  return null;
}
