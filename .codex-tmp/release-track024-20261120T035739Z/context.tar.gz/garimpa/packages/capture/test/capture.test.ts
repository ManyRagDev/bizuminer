/**
 * Testes da camada de captura.
 *
 * Nenhum toca a rede: o cliente HTTP é injetado. Isso permite rodar em CI,
 * testar caminhos de erro que a API real raramente produz sob demanda, e
 * verificar a assinatura sem precisar de credencial válida.
 *
 *   node --test --experimental-strip-types test/capture.test.ts
 */

import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";

import { toCents, toRate, fromEpochSeconds } from "../src/money.ts";
import { TokenBucket, withRetry } from "../src/rate-limit.ts";
import { CaptureError } from "../src/errors.ts";
import { mapProductNode, mapProductNodes } from "../src/adapters/shopee/mapper.ts";
import { ShopeeClient } from "../src/adapters/shopee/client.ts";
import { ShopeeAdapter } from "../src/adapters/shopee/index.ts";
import { PRODUCT_OFFER_QUERY, buildProductOfferQuery } from "../src/adapters/shopee/queries.ts";
import { AliExpressAdapter } from "../src/adapters/aliexpress/index.ts";
import type { CaptureContext, Credential } from "../src/types.ts";

const ctx: CaptureContext = { runId: "test", log: () => {} };
const cred: Credential = {
  marketplace: "shopee",
  secret: { appId: "APP123", appSecret: "SECRET456" },
};

function productArguments(body: { query: string; variables: Record<string, unknown> }): Record<string, any> {
  assert.deepEqual(body.variables, {});
  return Object.fromEntries([...body.query.matchAll(/\b(\w+): ("(?:\\.|[^"\\])*"|-?\d+)/g)]
    .map((match) => [match[1], JSON.parse(match[2]!)]));
}

// ---------------------------------------------------------------- dinheiro

describe("toCents", () => {
  it("converte sem erro de ponto flutuante", () => {
    // 29.90 * 100 === 2989.9999999999995 em float. Deve dar 2990.
    assert.equal(toCents(29.9), 2990);
    assert.equal(toCents("29.90"), 2990);
    assert.equal(toCents("29,90"), 2990);
  });

  it("entende separador de milhar nos dois formatos", () => {
    assert.equal(toCents("1.234,56"), 123456);
    assert.equal(toCents("1,234.56"), 123456);
    assert.equal(toCents("1234"), 123400);
  });

  it("arredonda o terceiro decimal", () => {
    assert.equal(toCents("10.005"), 1001);
    assert.equal(toCents("10.004"), 1000);
  });

  it("devolve undefined em vez de lançar", () => {
    assert.equal(toCents(null), undefined);
    assert.equal(toCents(""), undefined);
    assert.equal(toCents("abc"), undefined);
    assert.equal(toCents(NaN), undefined);
  });
});

describe("toRate", () => {
  it("normaliza fração e percentual", () => {
    assert.equal(toRate(0.15), 0.15);
    assert.equal(toRate(15), 0.15);
    assert.equal(toRate("0.07"), 0.07);
    assert.equal(toRate(1), 0.01);
    assert.equal(toRate("1"), 0.01);
    assert.equal(toRate(100), 1.0);
  });

  it("rejeita valores impossíveis", () => {
    assert.equal(toRate(150), undefined);
    assert.equal(toRate(-1), undefined);
  });
});

describe("fromEpochSeconds", () => {
  it("converte segundos e trata zero como ausência", () => {
    assert.equal(fromEpochSeconds(1_700_000_000)?.getUTCFullYear(), 2023);
    assert.equal(fromEpochSeconds(0), undefined);
    assert.equal(fromEpochSeconds(null), undefined);
  });
});

// ---------------------------------------------------------------- mapper

describe("mapProductNode", () => {
  const base = {
    itemId: 12345,
    shopId: 999,
    productName: "Fone Bluetooth",
    productLink: "https://shopee.com.br/product/999/12345",
    price: "189.90",
    priceDiscountRate: 0.4,
    commissionRate: 0.08,
  };

  it("mapeia os campos essenciais", () => {
    const offer = mapProductNode(base)!;
    assert.equal(offer.externalId, "12345");
    assert.equal(offer.externalShopId, "999");
    assert.equal(offer.priceCents, 18990);
    assert.equal(offer.claimedDiscountRate, 0.4);
    assert.equal(offer.source, "official_api");
  });

  it("deriva o preço original a partir do desconto declarado", () => {
    const offer = mapProductNode(base)!;
    // 189,90 com 40% de desconto => 316,50
    assert.equal(offer.originalPriceCents, 31650);
  });

  it("preserva faixa declarada e proveniência sem deduzir variante ou pacote", () => {
    const capturedAt = new Date("2026-10-05T12:00:00Z");
    const offer = mapProductNode({ ...base, priceMin: "20.29", priceMax: "48.99" }, capturedAt)!;
    assert.equal(offer.offerEvidence?.priceMinCents, 2029);
    assert.equal(offer.offerEvidence?.priceMaxCents, 4899);
    assert.deepEqual(offer.offerEvidence?.source, {
      marketplace: "shopee", method: "official_api",
      url: base.productLink, capturedAt: capturedAt.toISOString(),
    });
    assert.equal(offer.offerEvidence?.variantKey, undefined);
    assert.equal(offer.offerEvidence?.packageContents, undefined);
    assert.equal(offer.offerEvidence?.reviewCount, undefined);
    const withoutRange = mapProductNode(base)!;
    assert.equal(withoutRange.offerEvidence?.priceMinCents, undefined);
    assert.equal(withoutRange.offerEvidence?.priceMaxCents, undefined);
  });

  it("não usa preço máximo de variantes como preço riscado sem desconto declarado", () => {
    const offer = mapProductNode({
      ...base, price: undefined, priceMin: "10", priceMax: "30", priceDiscountRate: undefined,
    })!;
    assert.equal(offer.priceCents, 1000);
    assert.equal(offer.originalPriceCents, undefined);
    assert.equal(offer.offerEvidence?.priceMinCents, 1000);
    assert.equal(offer.offerEvidence?.priceMaxCents, 3000);
  });

  it("trata nota zero ou fora da escala como desconhecida", () => {
    for (const ratingStar of [0, "0", "", -1, 6, "não informado"]) {
      assert.equal(mapProductNode({ ...base, ratingStar })!.ratingStar, undefined);
    }
    assert.equal(mapProductNode({ ...base, ratingStar: "4.9" })!.ratingStar, 4.9);
  });

  it("descarta nó sem identidade, preço ou URL", () => {
    assert.equal(mapProductNode({ ...base, itemId: undefined }), null);
    assert.equal(mapProductNode({ ...base, productName: "  " }), null);
    assert.equal(mapProductNode({ ...base, price: "0" }), null);
    assert.equal(
      mapProductNode({ ...base, productLink: undefined, offerLink: undefined }),
      null,
    );
  });

  it("sobrevive a campos desconhecidos ou ausentes", () => {
    const offer = mapProductNode({
      itemId: 1,
      productName: "X",
      productLink: "https://x",
      price: 10,
      campoNovoQueAShopeeInventou: true,
    } as never)!;
    assert.equal(offer.priceCents, 1000);
    assert.equal(offer.commissionRate, undefined);
  });

  it("conta descartes em lote sem interromper o resto", () => {
    const { offers, skipped } = mapProductNodes([base, { itemId: 1 }, base]);
    assert.equal(offers.length, 2);
    assert.equal(skipped, 1);
  });
});

// ---------------------------------------------------------------- assinatura

describe("assinatura HMAC da Shopee", () => {
  it("segue o formato AppId + Timestamp + Payload + Secret", () => {
    const client = new ShopeeClient();
    const payload = '{"query":"{ x }","variables":{}}';
    const ts = 1_700_000_000;

    const header = client.buildAuthHeader(
      { appId: "APP123", appSecret: "SECRET456" },
      payload,
      ts,
    );

    const expected = createHash("sha256")
      .update(`APP123${ts}${payload}SECRET456`, "utf8")
      .digest("hex");

    assert.equal(
      header,
      `SHA256 Credential=APP123, Timestamp=${ts}, Signature=${expected}`,
    );
  });

  it("muda quando o corpo muda", () => {
    const client = new ShopeeClient();
    const a = client.buildAuthHeader({ appId: "A", appSecret: "S" }, "{}", 1);
    const b = client.buildAuthHeader({ appId: "A", appSecret: "S" }, "{ }", 1);
    assert.notEqual(a, b);
  });
});

// ---------------------------------------------------------------- erros

describe("tratamento de erro do cliente", () => {
  const fakeFetch = (status: number, body: unknown): typeof fetch =>
    (async () =>
      new Response(JSON.stringify(body), {
        status,
        headers: { "content-type": "application/json" },
      })) as unknown as typeof fetch;

  it("reconhece o código 10030 como limite de taxa", async () => {
    const client = new ShopeeClient({
      fetchImpl: fakeFetch(200, { errors: [{ extensions: { code: 10030 } }] }),
      ratePerSecond: 1000,
    });

    await assert.rejects(
      () => client.request({ appId: "a", appSecret: "b" }, "{ x }", {}, ctx),
      (err: unknown) =>
        err instanceof CaptureError &&
        err.kind === "rate_limit" &&
        err.retryable === true,
    );
  });

  it("trata 401 como credencial inválida e não repete", async () => {
    let calls = 0;
    const client = new ShopeeClient({
      ratePerSecond: 1000,
      fetchImpl: (async () => {
        calls++;
        return new Response("{}", { status: 401 });
      }) as unknown as typeof fetch,
    });

    await assert.rejects(
      () => client.request({ appId: "a", appSecret: "b" }, "{ x }", {}, ctx),
      (err: unknown) =>
        err instanceof CaptureError &&
        err.kind === "auth" &&
        err.needsOperatorAttention === true,
    );
    assert.equal(calls, 1, "credencial inválida não deve ser repetida");
  });

  it("trata código GraphQL 10020 (Invalid Signature) como auth e não repete", async () => {
    let calls = 0;
    const client = new ShopeeClient({
      ratePerSecond: 1000,
      fetchImpl: (async () => {
        calls++;
        return new Response(
          JSON.stringify({
            errors: [
              {
                message: "error [10020]: Invalid Signature",
                extensions: { code: 10020, message: "Invalid Signature" },
              },
            ],
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    await assert.rejects(
      () => client.request({ appId: "a", appSecret: "b" }, "{ x }", {}, ctx),
      (err: unknown) =>
        err instanceof CaptureError &&
        err.kind === "auth" &&
        err.vendorCode === 10020 &&
        err.retryable === false &&
        err.needsOperatorAttention === true,
    );
    assert.equal(calls, 1, "assinatura rejeitada não deve ser repetida");
  });

  it("erro de GraphQL com 200 não passa despercebido", async () => {
    const client = new ShopeeClient({
      ratePerSecond: 1000,
      fetchImpl: fakeFetch(200, { errors: [{ message: "campo inválido" }] }),
    });

    await assert.rejects(
      () => client.request({ appId: "a", appSecret: "b" }, "{ x }", {}, ctx),
      (err: unknown) =>
        err instanceof CaptureError && err.kind === "marketplace_error",
    );
  });
});

// ---------------------------------------------------------------- retry

describe("withRetry", () => {
  it("repete erro passível de retentativa e devolve o resultado", async () => {
    let attempts = 0;
    const result = await withRetry(
      async () => {
        attempts++;
        if (attempts < 3) {
          throw new CaptureError({
            kind: "rate_limit",
            marketplace: "shopee",
            message: "limite",
            retryAfterMs: 1,
          });
        }
        return "ok";
      },
      { baseDelayMs: 1, random: () => 0 },
    );

    assert.equal(result, "ok");
    assert.equal(attempts, 3);
  });

  it("não repete erro de credencial", async () => {
    let attempts = 0;
    await assert.rejects(() =>
      withRetry(
        async () => {
          attempts++;
          throw new CaptureError({ kind: "auth", marketplace: "shopee", message: "x" });
        },
        { baseDelayMs: 1, random: () => 0 },
      ),
    );
    assert.equal(attempts, 1);
  });

  it("aplica jitter — o atraso não é determinístico entre execuções", async () => {
    const delays: number[] = [];
    await assert.rejects(() =>
      withRetry(
        async () => {
          throw new CaptureError({ kind: "transport", marketplace: "s", message: "x" });
        },
        {
          maxAttempts: 4,
          baseDelayMs: 100,
          random: () => 0.5,
          onRetry: ({ delayMs }) => delays.push(delayMs),
        },
      ),
    );
    // metade do teto exponencial: 50, 100, 200
    assert.deepEqual(delays, [50, 100, 200]);
  });
});

// ---------------------------------------------------------------- token bucket

describe("TokenBucket", () => {
  it("libera até o limite de rajada e depois espaça", () => {
    let now = 0;
    const bucket = new TokenBucket(2, 2, () => now);
    assert.equal(Math.floor(bucket.available), 2);
    now += 1000;
    assert.equal(Math.floor(bucket.available), 2, "não acumula além da rajada");
  });
});

// ---------------------------------------------------------------- adapter

describe("ShopeeAdapter", () => {
  const okResponse = (nodes: unknown[], hasNextPage = false) =>
    (async () =>
      new Response(
        JSON.stringify({
          data: { productOfferV2: { nodes, pageInfo: { hasNextPage } } },
        }),
        { status: 200, headers: { "content-type": "application/json" } },
      )) as unknown as typeof fetch;

  const node = {
    itemId: 1,
    shopId: 2,
    productName: "Produto",
    productLink: "https://shopee.com.br/p/1",
    price: "50.00",
    priceDiscountRate: 0.5,
  };

  it("declara que usa API oficial, não scraping", () => {
    const adapter = new ShopeeAdapter();
    assert.equal(adapter.capabilities.source, "official_api");
  });

  it("devolve ofertas normalizadas e cursor da próxima página", async () => {
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      fetchImpl: okResponse([node], true),
    });

    const page = await adapter.fetchOffers(cred, {}, ctx);
    assert.equal(page.offers.length, 1);
    assert.equal(page.offers[0]!.priceCents, 5000);
    assert.equal(page.nextCursor, "page:2");
  });

  it("reduz a primeira página após 10000 persistente e mantém o limite na próxima página", async (test) => {
    test.mock.method(Math, "random", () => 0);
    const calls: { page: number; limit: number; keyword: string }[] = [];
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      fetchImpl: async (_input, init) => {
        const variables = productArguments(JSON.parse(String(init?.body))) as { page: number; limit: number; keyword: string };
        calls.push(variables);
        if (variables.limit === 50) return Response.json({ errors: [{ extensions: { code: 10000 } }] });
        return okResponse([node], variables.page === 1)(_input, init);
      },
    });
    const first = await adapter.fetchOffers(cred, { keyword: "fone" }, ctx);
    assert.equal(first.nextCursor, "page:2:20");
    const second = await adapter.fetchOffers(cred, { keyword: "fone", cursor: first.nextCursor }, ctx);
    assert.equal(second.nextCursor, undefined);
    assert.equal(calls.filter(call => call.limit === 50).length, 5);
    assert.deepEqual(calls.slice(-2).map(({ page, limit, keyword }) => [page, limit, keyword]), [[1, 20, "fone"], [2, 20, "fone"]]);
  });

  it("trata a falta da lista de produtos como falha de resposta", async () => {
    const adapter = new ShopeeAdapter({
      fetchImpl: async () => Response.json({ data: { productOfferV2: null } }),
    });
    await assert.rejects(adapter.fetchOffers(cred, {}, ctx), { kind: "malformed_response" });
  });

  it("aplica filtro de desconto mínimo", async () => {
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      fetchImpl: okResponse([node, { ...node, itemId: 2, priceDiscountRate: 0.1 }]),
    });

    const page = await adapter.fetchOffers(cred, { minClaimedDiscount: 0.3 }, ctx);
    assert.equal(page.offers.length, 1);
    assert.equal(page.offers[0]!.externalId, "1");
  });

  it("rejeita credencial incompleta sem vazar o segredo na mensagem", async () => {
    const adapter = new ShopeeAdapter({ ratePerSecond: 1000 });
    await assert.rejects(
      () =>
        adapter.fetchOffers(
          { marketplace: "shopee", secret: { appId: "so-o-id" } },
          {},
          ctx,
        ),
      (err: unknown) => {
        assert.ok(err instanceof CaptureError);
        assert.equal(err.kind, "auth");
        assert.match(err.message, /appSecret/);
        assert.doesNotMatch(err.message, /so-o-id/);
        return true;
      },
    );
  });

  it("streamOffers percorre as páginas e para no fim", async () => {
    let call = 0;
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      fetchImpl: (async () => {
        call++;
        return new Response(
          JSON.stringify({
            data: {
              productOfferV2: {
                nodes: [{ ...node, itemId: call }],
                pageInfo: { hasNextPage: call < 3 },
              },
            },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    const seen: string[] = [];
    for await (const batch of adapter.streamOffers(cred, {}, ctx)) {
      for (const o of batch) seen.push(o.externalId);
    }

    assert.deepEqual(seen, ["1", "2", "3"]);
  });

  it("ShopeeAdapter suporta consulta por departamento com ordenação sales e omite keyword", async () => {
    let capturedBody: any;
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      fetchImpl: (async (_url: string, init: RequestInit) => {
        const body = JSON.parse(init.body as string);
        capturedBody = { variables: productArguments(body) };
        return new Response(
          JSON.stringify({
            data: {
              productOfferV2: {
                nodes: [{ ...node, itemId: 100, productCatIds: [100636] }],
                pageInfo: { hasNextPage: false },
              },
            },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    const page = await adapter.fetchOffers(
      cred,
      {
        sourceQuery: { kind: "department", categoryId: "100636", order: "sales" },
      },
      ctx,
    );

    assert.equal(page.offers.length, 1);
    assert.equal(page.offers[0]!.externalId, "100");
    assert.equal(capturedBody.variables.productCatId, 100636);
    assert.equal(Object.hasOwn(capturedBody.variables, "listType"), false);
    assert.equal(capturedBody.variables.sortType, 2);
    assert.equal(Object.hasOwn(capturedBody.variables, "keyword"), false);
    assert.equal(Object.hasOwn(capturedBody.variables, "shopId"), false);
  });

  it("ShopeeAdapter omite ordenação default e rejeita discount antes da rede", async () => {
    let capturedBody: any;
    let calls = 0;
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      fetchImpl: (async (_url: string, init: RequestInit) => {
        calls++;
        const body = JSON.parse(init.body as string);
        capturedBody = { variables: productArguments(body) };
        return new Response(
          JSON.stringify({
            data: {
              productOfferV2: {
                nodes: [{ ...node, itemId: 101, productCatIds: [100636] }],
                pageInfo: { hasNextPage: false },
              },
            },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    await adapter.fetchOffers(
      cred,
      {
        sourceQuery: { kind: "department", categoryId: "100636", order: "default" },
      },
      ctx,
    );
    assert.equal(Object.hasOwn(capturedBody.variables, "sortType"), false);
    assert.equal(Object.hasOwn(capturedBody.variables, "listType"), false);

    await assert.rejects(adapter.fetchOffers(
      cred,
      {
        sourceQuery: { kind: "department", categoryId: "100636", order: "discount" },
      },
      ctx,
    ), { kind: "marketplace_error", message: "shopee_discount_order_unsupported" });
    assert.equal(calls, 1);
  });

  it("ShopeeClient repete e recupera em erro de sistema 10000", async () => {
    let attempts = 0;
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      fetchImpl: (async () => {
        attempts++;
        if (attempts === 1) {
          return new Response(
            JSON.stringify({
              errors: [{ message: "System Error", extensions: { code: 10000 } }],
            }),
            { status: 200, headers: { "content-type": "application/json" } },
          );
        }
        return new Response(
          JSON.stringify({
            data: {
              productOfferV2: {
                nodes: [{ ...node, itemId: 200 }],
                pageInfo: { hasNextPage: false },
              },
            },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    const page = await adapter.fetchOffers(cred, {}, ctx);
    assert.equal(attempts, 2);
    assert.equal(page.offers.length, 1);
    assert.equal(page.offers[0]!.externalId, "200");
  });

  it("omite filtros opcionais não informados e assina exatamente o payload literal serializado", async () => {
    let calls = 0;
    const variables: Record<string, unknown>[] = [];
    const adapter = new ShopeeAdapter({
      ratePerSecond: 1000,
      now: () => 1_700_000_000_000,
      fetchImpl: async (_url, init) => {
        calls++;
        const serialized = String(init?.body);
        const body = JSON.parse(serialized);
        const args = productArguments(body);
        variables.push(args);
        assert.equal(body.query, buildProductOfferQuery(args));
        assert.ok(Object.values(args).every((value) => value !== null && value !== undefined));
        const signature = createHash("sha256").update(`APP1231700000000${serialized}SECRET456`, "utf8").digest("hex");
        assert.equal(new Headers(init?.headers).get("Authorization"), `SHA256 Credential=APP123, Timestamp=1700000000, Signature=${signature}`);
        return Response.json({ data: { productOfferV2: { nodes: [], pageInfo: { hasNextPage: false } } } });
      },
    });
    await adapter.fetchOffers(cred, { keyword: "organização ç" }, ctx);
    await adapter.fetchOffers(cred, { sourceQuery: { kind: "department", categoryId: "100636", order: "default" } }, ctx);
    await adapter.fetchOffers(cred, { shopId: "0", pageSize: 1 }, ctx);
    assert.equal(calls, 3);
    assert.deepEqual(variables, [
      { keyword: "organização ç", page: 1, limit: 50, sortType: 2 },
      { productCatId: 100636, page: 1, limit: 50 },
      { shopId: 0, page: 1, limit: 1, sortType: 2 },
    ]);
  });

  it("rejeita números inválidos antes da rede sem converter filtros em null ou ampliar departamento", async () => {
    let calls = 0;
    const adapter = new ShopeeAdapter({ fetchImpl: async () => { calls++; return Response.json({}); } });
    for (const pageSize of [NaN, Infinity, -Infinity, 0, -1, 1.5]) {
      await assert.rejects(adapter.fetchOffers(cred, { pageSize }, ctx), { kind: "marketplace_error" });
    }
    for (const value of ["NaN", "Infinity", "-Infinity", "private-filter", "", "1.5", "9007199254740993"]) {
      await assert.rejects(adapter.fetchOffers(cred, { shopId: value }, ctx), { kind: "marketplace_error" });
      await assert.rejects(adapter.fetchOffers(cred, { sourceQuery: { kind: "department", categoryId: value } }, ctx), { kind: "marketplace_error" });
    }
    assert.equal(calls, 0);
    const client = new ShopeeClient({ fetchImpl: async () => { calls++; return Response.json({}); } });
    for (const variables of [{ page: NaN }, { shopId: Infinity }, { input: { nested: [-Infinity] } }]) {
      await assert.rejects(client.request({ appId: "a", appSecret: "b" }, PRODUCT_OFFER_QUERY, variables, ctx), { kind: "marketplace_error" });
    }
    assert.equal(calls, 0);
  });

  it("erro GraphQL determinístico não repete transporte nem aplica fallback de página, inclusive com10000", async () => {
    const errors = [
      [{ message: "graphql: got null for non-null", extensions: { code: 10000 } }],
      [{ message: "graphql: got null for non-null", extensions: { code: "private-secret-code" } }],
      ...["GRAPHQL_PARSE", "GRAPHQL_PARSE_FAILED", "GRAPHQL_VALIDATION", "GRAPHQL_VALIDATION_FAILED"].map((code) => [{ message: "private-secret-provider-message", extensions: { code } }]),
      [{ message: "System Error", extensions: { code: 10000 } }, { message: "private-secret-provider-message", extensions: { code: "GRAPHQL_VALIDATION_FAILED" } }],
    ];
    for (const errorList of errors) {
      let calls = 0;
      let retries = 0;
      const adapter = new ShopeeAdapter({ ratePerSecond: 1000, fetchImpl: async () => {
        calls++;
        return Response.json({ errors: errorList });
      } });
      await assert.rejects(adapter.fetchOffers(cred, { keyword: "fone", pageSize: 50 }, { runId: "test", log: () => { retries++; } }), (error: unknown) => {
        assert.ok(error instanceof CaptureError);
        assert.equal(error.kind, "marketplace_error");
        assert.equal(error.retryable, false);
        assert.equal(error.message, "graphql_contract_error");
        assert.doesNotMatch(JSON.stringify(error.toLogSafe()), /private-secret/);
        return true;
      });
      assert.equal(calls, 1);
      assert.equal(retries, 0);
    }
  });
});

describe("AliExpressAdapter — departamento e ordenação", () => {
  const aliCred: Credential = {
    marketplace: "aliexpress",
    secret: { appKey: "KEY123", appSecret: "SECRET456", trackingId: "TRACK789" },
  };

  const aliProduct = {
    product_id: 99999,
    product_title: "Kit Ferramentas Completo",
    product_detail_url: "https://pt.aliexpress.com/item/99999.html",
    promotion_link: "https://s.click.aliexpress.com/e/abc",
    target_sale_price: "89.90",
    target_sale_price_currency: "BRL",
    first_level_category_id: "1420",
    first_level_category_name: "Ferramentas",
  };

  it("envia category_ids e sort LAST_VOLUME_DESC para ordenação sales sem keyword", async () => {
    let requestBody: string = "";
    const adapter = new AliExpressAdapter({
      fetchImpl: (async (_url: string, init: RequestInit) => {
        requestBody = String(init?.body ?? "");
        return new Response(
          JSON.stringify({
            aliexpress_affiliate_product_query_response: {
              resp_result: {
                result: {
                  products: { product: [aliProduct] },
                  total_record_count: 1,
                  current_record_count: 1,
                },
              },
            },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    const page = await adapter.fetchOffers(
      aliCred,
      {
        sourceQuery: { kind: "department", categoryId: "1420", order: "sales" },
      },
      ctx,
    );

    assert.equal(page.offers.length, 1);
    assert.equal(page.offers[0]!.externalId, "99999");
    assert.ok(requestBody.includes("category_ids=1420"));
    assert.ok(requestBody.includes("sort=LAST_VOLUME_DESC"));
    assert.ok(!requestBody.includes("keywords="));
  });

  it("omite sort para ordenação default", async () => {
    let requestBody: string = "";
    const adapter = new AliExpressAdapter({
      fetchImpl: (async (_url: string, init: RequestInit) => {
        requestBody = String(init?.body ?? "");
        return new Response(
          JSON.stringify({
            aliexpress_affiliate_product_query_response: {
              resp_result: {
                result: {
                  products: { product: [aliProduct] },
                  total_record_count: 1,
                  current_record_count: 1,
                },
              },
            },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    await adapter.fetchOffers(
      aliCred,
      {
        sourceQuery: { kind: "department", categoryId: "1420", order: "default" },
      },
      ctx,
    );

    assert.ok(requestBody.includes("category_ids=1420"));
    assert.ok(!requestBody.includes("sort="));
  });

  it("envia sort DISCOUNT_DESC para ordenação discount", async () => {
    let requestBody: string = "";
    const adapter = new AliExpressAdapter({
      fetchImpl: (async (_url: string, init: RequestInit) => {
        requestBody = String(init?.body ?? "");
        return new Response(
          JSON.stringify({
            aliexpress_affiliate_product_query_response: {
              resp_result: {
                result: {
                  products: { product: [aliProduct] },
                  total_record_count: 1,
                  current_record_count: 1,
                },
              },
            },
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }) as unknown as typeof fetch,
    });

    await adapter.fetchOffers(
      aliCred,
      {
        sourceQuery: { kind: "department", categoryId: "1420", order: "discount" },
      },
      ctx,
    );

    assert.ok(requestBody.includes("category_ids=1420"));
    assert.ok(requestBody.includes("sort=DISCOUNT_DESC"));
  });
});
