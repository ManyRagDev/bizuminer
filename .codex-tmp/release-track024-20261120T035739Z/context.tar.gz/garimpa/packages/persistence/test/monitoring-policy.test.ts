import assert from "node:assert/strict";
import test from "node:test";
import { monitoringDecision, monitoringQueue, type MonitoringCandidate } from "../src/monitoring-policy.ts";
import { missingRetryHours } from "../src/monitoring-candidates.ts";

const now = new Date("2026-09-24T12:00:00Z");
const candidate = (id: string, overrides: Partial<MonitoringCandidate> = {}): MonitoringCandidate => ({
  productId: id,
  marketplace: "shopee",
  lastObservedAt: new Date("2026-09-22T00:00:00Z"),
  activeWatches: 0,
  clicks7d: 0,
  curationStatus: "pending",
  ...overrides,
});

test("interesse explícito vem primeiro; ML vai para revisão humana", () => {
  const decision = monitoringDecision(candidate("ml", { marketplace: "mercadolivre", activeWatches: 1 }), now);
  assert.equal(decision.tier, "watch");
  assert.equal(decision.targetHours, 24);
  assert.equal(decision.lane, "human");
  assert.equal(decision.due, true);
});

test("produto rejeitado ou retido não consome consultas sem interesse", () => {
  assert.equal(monitoringDecision(candidate("held", { curationStatus: "held" }), now).due, false);
  assert.equal(monitoringDecision(candidate("legacy", { curationStatus: "legacy_visible" }), now).due, false);
  assert.equal(monitoringDecision(candidate("held", { curationStatus: "held", activeWatches: 1 }), now).tier, "watch");
});

test("fila respeita orçamento, loja e faixa antes do atraso", () => {
  const queue = monitoringQueue([
    candidate("old-pending", { lastObservedAt: new Date("2026-09-14T00:00:00Z") }),
    candidate("watched", { activeWatches: 1 }),
    candidate("edition", { curationStatus: "approved", inCurrentEdition: true }),
    candidate("approved-idle", { curationStatus: "approved", inCurrentEdition: false }),
    candidate("ali", { marketplace: "aliexpress", activeWatches: 1 }),
  ], "shopee", 2, now);
  assert.deepEqual(queue.map((item) => item.productId), ["watched", "edition"]);
});

test("acompanhamentos mantêm prioridade sobre edição vigente e candidatos sem interesse não consomem cota", () => {
  const editionItems = Array.from({ length: 20 }, (_, i) => candidate(`edition-${i}`, { curationStatus: "approved", inCurrentEdition: true }));
  const queue = monitoringQueue([...editionItems,
    candidate("watched-a", { activeWatches: 1, lastObservedAt: new Date("2026-09-14T00:00:00Z") }),
    candidate("candidate-b", { lastObservedAt: new Date("2026-09-14T00:00:00Z") }),
  ], "shopee", 10, now);
  assert.equal(queue.length, 10);
  assert.equal(queue.filter((entry) => entry.tier === "watch").length, 1);
  assert.equal(queue.some((entry) => entry.productId === "candidate-b"), false);
});

test("candidato sem aprovação sai da fila após duas semanas sem captura", () => {
  assert.equal(monitoringDecision(candidate("old", { lastObservedAt: new Date("2026-09-01T00:00:00Z") }), now).tier, "archive");
});

test("ausências repetidas recebem recuo progressivo, menor para itens observados pelo usuário", () => {
  assert.deepEqual([1, 2, 3, 4].map((n) => missingRetryHours(n, false)), [24, 72, 168, 336]);
  assert.deepEqual([1, 2, 3, 4].map((n) => missingRetryHours(n, true)), [6, 24, 72, 72]);
});

test("produtos com favoritos/alertas têm vencimento a cada 24h e precedem vitrine", () => {
  const userFavorite = candidate("fav-1", { activeWatches: 1, lastObservedAt: new Date("2026-09-23T10:00:00Z") });
  const decision = monitoringDecision(userFavorite, now);
  assert.equal(decision.tier, "watch");
  assert.equal(decision.targetHours, 24);
  assert.equal(decision.due, true);

  const approvedItem = candidate("app-1", { curationStatus: "approved", lastObservedAt: new Date("2026-09-21T00:00:00Z") });
  const queue = monitoringQueue([approvedItem, userFavorite], "shopee", 1, now);
  assert.equal(queue[0]?.productId, "fav-1");
});

test("edição atual é conferida antes de vencer o preço, sem exceder orçamento ou passar favoritos", () => {
  const edition = candidate("edition", { curationStatus: "approved", inCurrentEdition: true,
    lastObservedAt: new Date(+now - 25 * 3600000) });
  assert.equal(monitoringDecision(edition, now).targetHours, 24);
  assert.equal(monitoringDecision(edition, now).tier, "edition");
  const pool = [candidate("approved", { curationStatus: "approved" }), edition, candidate("favorite", { activeWatches: 1 })];
  assert.deepEqual(monitoringQueue(pool, "shopee", 2, now).map(d => d.productId), ["favorite", "edition"]);
  assert.equal(monitoringQueue(pool, "shopee", 1, now).length, 1);
  assert.notEqual(monitoringDecision({ ...edition, curationStatus: "rejected" }, now).tier, "edition");
});

