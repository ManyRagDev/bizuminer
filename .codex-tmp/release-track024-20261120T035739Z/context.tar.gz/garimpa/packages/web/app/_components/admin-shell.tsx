"use client";

import Image from "next/image";
import Link from "next/link";
import AdminLink from "./admin-link.tsx";
import { useState,useEffect,useRef } from "react";
import { usePathname, useSearchParams } from "next/navigation";

interface NavItem {
  id: string;
  href: string;
  label: string;
  icon: string;
  badge?: number;
  badgeType?: "warning" | "neutral";
  executionBadge?: number;
}

interface NavGroup {
  groupTitle: string;
  items: NavItem[];
  collapsed?: boolean;
}

function resolveActiveId(pathname: string, search: string): string {
  if (pathname.startsWith("/admin/configuracoes")) return "configuracoes";
  if (pathname.startsWith("/admin/financeiro") || pathname.startsWith("/admin/resultados")) return "financeiro";
  if (pathname.startsWith("/admin/capturas")) return "operacao";
  if (pathname.startsWith("/admin/onboarding")) return "onboarding";
  if (pathname.startsWith("/admin/governanca")) return "governanca";
  if (pathname.startsWith("/admin/campanhas")) return "campanhas";
  if (pathname.startsWith("/admin/financeiro")) return "financeiro";
  if (pathname.startsWith("/admin/experimentos")) return "experimentos";
  if (pathname === "/pauta") return "publicar";
  if (pathname.startsWith("/admin/marketing")) return "marketing";

  if (pathname.startsWith("/admin/curadoria") || pathname.startsWith("/admin/direcionamento")) {
    const params = new URLSearchParams(search);
    const aba = params.get("aba");
    if (aba === "bussola" || pathname.startsWith("/admin/direcionamento")) return "configuracoes";
    if (aba === "pipeline" || aba === "lotes") return "curadoria";
    return "curadoria";
  }

  if (pathname === "/admin") {
    const params = new URLSearchParams(search);
    const aba = params.get("aba");
    if (aba === "rodagens") return "rodagens";
    if (aba === "captura-manual") return "operacao";
    if (aba === "afiliados") return "configuracoes";
    if (aba === "publicacao") return "publicar";
    return "hoje";
  }

  return "hoje";
}

function resolveSectionTitle(activeId: string): string {
  switch (activeId) {
    case "hoje": return "Painel · Hoje";
    case "onboarding": return "Painel · Primeiros Passos";
    case "governanca": return "Painel · Governança";
    case "curadoria": return "Painel · Curadoria";
    case "publicar": return "Painel · Pauta";
    case "marketing": return "Painel · Marketing";
    case "campanhas": return "Painel · Campanhas";
    case "financeiro": return "Painel · Resultados";
    case "experimentos": return "Painel · Experimentos de Políticas";
    case "operacao": return "Painel · Capturas";
    case "rodagens": return "Painel · Comandos de captura";
    case "configuracoes": return "Painel · Configurações";
    default:
      return "Painel do Administrador";
  }
}

export default function AdminShell({
  children,
  curationCount = 0,
  curationExecutionCount = 0,
  accountHeader,
  workspace=false,
  tenantId,
  curationStatusAvailable=true,
}: {
  children: React.ReactNode;
  curationCount?: number;
  curationExecutionCount?: number;
  accountHeader?: React.ReactNode;
  workspace?: boolean;
  tenantId?:string;
  curationStatusAvailable?:boolean;
}) {
  const pathname = usePathname();
  const currentSearch = useSearchParams().toString();
  const capturesHref=`/admin/capturas${tenantId ? `?${new URLSearchParams({conta:tenantId})}` : ''}`;
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [mobile,setMobile]=useState(false),toggle=useRef<HTMLButtonElement>(null);
  useEffect(()=>{const media=window.matchMedia('(max-width: 820px)'),update=()=>setMobile(media.matches);update();media.addEventListener('change',update);return()=>media.removeEventListener('change',update);},[]);

  const activeId = workspace
    ? pathname.startsWith("/admin/ofertas")
      ? "ofertas"
      : pathname.startsWith("/admin/divulgacoes") || pathname.startsWith("/admin/marketing")
        ? "divulgacoes"
        : pathname.startsWith("/admin/resultados") || pathname.startsWith("/admin/financeiro")
          ? "resultados"
          : pathname.startsWith("/admin/configuracoes") || pathname.startsWith("/admin/onboarding")
            ? "ajustes"
            : pathname === "/pauta"
              ? "pauta"
              : pathname.startsWith("/admin/curadoria")
                ? "curadoria"
                : pathname.startsWith("/admin/capturas") || pathname === "/admin" && ["rodagens", "captura-manual"].includes(new URLSearchParams(currentSearch).get("aba") ?? "")
                  ? "operacao"
                  : pathname === "/admin" && [null, "visao-geral"].includes(new URLSearchParams(currentSearch).get("aba"))
                    ? "hoje"
                    : "avancado"
    : resolveActiveId(pathname, currentSearch);
  const sectionTitle = workspace
    ? ({
        hoje: "Hoje",
        ofertas: "Ofertas",
        divulgacoes: "Divulgações",
        resultados: "Resultados",
        ajustes: "Configurações",
        pauta: "Pauta Rápida",
        curadoria: "Curadoria Geral",
        operacao: "Operação & Captura",
        avancado: "Ferramentas avançadas",
      }[activeId] ?? "Meu negócio")
    : resolveSectionTitle(activeId);
  const onPauta = pathname === "/pauta";

  const navigationGroups: NavGroup[] = workspace
    ? [
        {
          groupTitle: "Meu negócio",
          items: [
            { id: "hoje", href: "/admin", label: "Hoje", icon: "◉" },
            { id: "ofertas", href: "/admin/ofertas", label: "Ofertas", icon: "◇" },
            { id: "divulgacoes", href: "/admin/divulgacoes", label: "Divulgações", icon: "↗" },
            { id: "resultados", href: "/admin/resultados", label: "Resultados", icon: "▥" },
          ],
        },
        {
          groupTitle: "Ferramentas & Catálogo",
          items: [
            { id: "pauta", href: "/pauta", label: "Pauta Rápida", icon: "📱" },
            { id: "curadoria", href: "/admin/curadoria?aba=selecao", label: "Curadoria Geral", icon: "🎯" },
            { id: "operacao", href: capturesHref, label: "Capturas", icon: "🔄" },
          ],
        },
        {
          groupTitle: "Minha conta",
          items: [
            { id: "ajustes", href: "/admin/configuracoes", label: "Configurações", icon: "⚙" },
          ],
        },
      ]
    : [
      {groupTitle: "Operação", items: [
        {id:"hoje",href:"/admin",label:"Hoje",icon:"☀️"},
        {id:"operacao",href:capturesHref,label:"Capturas",icon:"🔄"},
        {id:"curadoria",href:"/admin/curadoria?aba=andamento",label:"Curadoria",icon:"🎯",
          badge:curationCount>0?curationCount:undefined,badgeType:"warning",executionBadge:curationExecutionCount},
        {id:"publicar",href:"/pauta",label:"Pauta",icon:"📱"},
        {id:"financeiro",href:"/admin/financeiro",label:"Resultados",icon:"↗"},
      ]},
      {groupTitle:"Conta",items:[{id:"configuracoes",href:"/admin/configuracoes",label:"Configurações",icon:"⚙️"}]},
      {groupTitle:"Conteúdo",collapsed:true,items:[
        {id:"marketing",href:"/admin/marketing",label:"Marketing",icon:"✦"},
        {id:"campanhas",href:"/admin/campanhas",label:"Campanhas",icon:"▣"}]},
      {groupTitle:"Ferramentas avançadas",collapsed:true,items:[
        {id:"rodagens",href:"/admin?aba=rodagens",label:"Comandos de captura",icon:"↻"},
        {id:"governanca",href:"/admin/governanca",label:"Governança",icon:"⚖️"},
        {id:"experimentos",href:"/admin/experimentos",label:"Experimentos",icon:"🧪"}]},
    ];
  const accountHref=(href:string)=>{
    if(!tenantId) return href;
    const url=new URL(href,"https://local.invalid");url.searchParams.set("conta",tenantId);
    return url.pathname+url.search+url.hash;
  };

  return (
    <main className="admin-page admin-shell" onKeyDown={event=>{if(event.key==='Escape'&&drawerOpen){setDrawerOpen(false);toggle.current?.focus();}}}>
      {/* Top Header */}
      <header className="detail-header admin-shell-header">
        <div className="admin-header-left">
          <Link className="brand" href="/" aria-label="BizuMiner, início">
            <Image
              src="/brand/bizuminer-icon-light.svg"
              alt=""
              aria-hidden="true"
              width={32}
              height={32}
              priority
              className="brand-mark-img"
            />
            <span className="brand-name">
              <b>Bizu</b>
              <i>Miner</i>
            </span>
          </Link>
          <span className="admin-tag admin-shell-tag">{sectionTitle}</span>
          {accountHeader}
        </div>

        <div className="detail-header-actions">
          {!workspace && !onPauta && activeId !== "marketing" && (
            <Link
              href={accountHref("/pauta")}
              className="admin-shell-pauta-link"
              title="Abrir a Pauta de WhatsApp e Stories"
            >
              📱 Pauta
            </Link>
          )}
          <a href="/" className="admin-shell-site-link" target="_blank" rel="noopener noreferrer">
            Ver Vitrine ↗
          </a>
          <form action="/auth/sair" method="post" className="admin-signout-form">
            <button className="auth-signout" type="submit" title="Encerrar sessão de administrador">
              Sair
            </button>
          </form>
          <button
            type="button"
            ref={toggle}
            className="admin-shell-toggle"
            aria-expanded={drawerOpen}
            aria-controls="admin-shell-nav"
            aria-label={drawerOpen ? "Fechar menu de navegação" : "Abrir menu de navegação"}
            onClick={() => setDrawerOpen((value) => !value)}
          >
            ☰
          </button>
        </div>
      </header>

      {/* Main Body with Unified Sidebar */}
      <div className="admin-shell-body">
        <nav
          id="admin-shell-nav"
          className={"admin-shell-nav" + (drawerOpen ? " open" : "")}
          aria-label={workspace?'Navegação do negócio':'Navegação administrativa'}
          inert={mobile&&!drawerOpen}
        >
          <div className="admin-shell-nav-inner">
            {navigationGroups.map((group) => {
              const Group = group.collapsed ? "details" : "div";
              return (
              <Group key={group.groupTitle} className="admin-nav-group" {...(group.collapsed?{open:group.items.some(item=>item.id===activeId)||undefined}:{})}>
                {group.collapsed?<summary className="admin-nav-group-title">{group.groupTitle}</summary>:<span className="admin-nav-group-title">{group.groupTitle}</span>}
                <div className="admin-nav-group-items">
                  {group.items.map((item) => {
                    const isActive = activeId === item.id;
                    return (
                      <AdminLink
                        key={item.id}
                        href={accountHref(item.href)}
                        className={"admin-shell-nav-item" + (isActive ? " active" : "")}
                        aria-current={isActive ? "page" : undefined}
                        onClick={() => {
                          setDrawerOpen(false);
                        }}
                      >
                        <span className="admin-nav-item-content">
                          <span className="admin-nav-item-icon" aria-hidden="true">
                            {item.icon}
                          </span>
                          <span className="admin-nav-item-label">{item.label}</span>
                        </span>
                        {item.id==='curadoria'&&!curationStatusAvailable&&<span className="admin-shell-nav-count" title="Contagem da curadoria indisponível" aria-label="Contagem da curadoria indisponível">?</span>}
                        {curationStatusAvailable && item.badge !== undefined && item.badge > 0 && (
                          <span className={`admin-shell-nav-count ${item.badgeType || "neutral"}`}>
                            {item.badge}
                          </span>
                        )}
                        {curationStatusAvailable && item.executionBadge !== undefined && item.executionBadge > 0 && (
                          <span className="admin-shell-nav-count warning" title="Avaliações com resultado incerto"
                            aria-label={`${item.executionBadge} avaliações com resultado incerto`}>
                            {item.executionBadge} incertas
                          </span>
                        )}
                      </AdminLink>
                    );
                  })}
                </div>
              </Group>
            );})}

            <div className="admin-shell-nav-foot">
              <Link href="/" className="nav-foot-site">
                🌐 Ver Vitrine Pública
              </Link>
              <form action="/auth/sair" method="post">
                <button className="auth-signout" type="submit">
                  Encerrar Sessão
                </button>
              </form>
            </div>
          </div>
        </nav>

        <div className="admin-shell-content">{children}</div>
      </div>

      {drawerOpen && (
        <button
          type="button"
          className="admin-shell-overlay"
          aria-label="Fechar navegação"
          onClick={() => {setDrawerOpen(false);toggle.current?.focus();}}
        />
      )}
    </main>
  );
}
