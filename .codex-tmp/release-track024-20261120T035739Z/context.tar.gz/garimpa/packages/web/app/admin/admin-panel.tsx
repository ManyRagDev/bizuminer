"use client";

import { useAdminDraftState, useResumeAfterOperation, useAdminFetch } from "./draft-provider.tsx";

import { Fragment, useEffect, useState, type ReactNode } from "react";
import {
  groupAdminRuns,
  toAdminRun,
  type AdminRun,
  type AdminRunGroupStatus,
  type AdminRunSource,
} from "../../lib/admin-run-groups";
import { captureTriggerFailureMessage } from "../../lib/capture-trigger-feedback.ts";

export type { AdminRun } from "../../lib/admin-run-groups";

type RunsResponse = {
  ok: boolean;
  runs?: AdminRunSource[];
  runningId?: string | null;
};

const POLL_MS = 5000;
const SPAWN_TIMEOUT_MS = 30_000;

const dateTime = (isoDate: string) =>
  new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(isoDate));

function duration(run: { startedAt: string; finishedAt: string | null }): string {
  if (!run.finishedAt) return "—";
  const ms = new Date(run.finishedAt).getTime() - new Date(run.startedAt).getTime();
  if (ms < 0) return "—";
  const seconds = Math.round(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  return `${Math.floor(seconds / 60)}m${String(seconds % 60).padStart(2, "0")}s`;
}

function statusLabel(status: AdminRunGroupStatus, itemsCaptured: number): { className: string; label: string } {
  if (status === "running") return { className: "running", label: "rodando" };
  if (status === "partial") return { className: "partial", label: "parcial" };
  if (status === "error") return { className: "error", label: "erro" };
  if (itemsCaptured === 0) return { className: "empty", label: "vazia" };
  return { className: "ok", label: "ok" };
}

function parseRuns(payload: RunsResponse): AdminRun[] {
  return (payload.runs ?? []).map(toAdminRun);
}

function modeLabel(mode: string | null): string {
  if (mode === "directed") return "dirigida";
  if (mode === "exploratory") return "exploratória";
  return "avulsa";
}

/**
 * Rodagens de UMA plataforma — parametrizado por `marketplace` (M4,
 * `docs/tecnico/plano-multiplataforma.md`). O Mercado Livre continua com o
 * mesmo comportamento de sempre (kill switch E0, aviso de captura manual);
 * cada plataforma nova só precisa de `triggerPath`/`enabled`/`disabledNotice`
 * próprios — este componente não sabe o nome de nenhuma plataforma.
 */
export default function AdminPanel({
  marketplace,
  marketplaceLabel,
  triggerPath,
  initialRuns,
  initialRunningId,
  enabled,
  disabledNotice,
  requiresConsent,
  trialSingleProduct = false,
}: {
  marketplace: string;
  marketplaceLabel: string;
  /** Endpoint POST que aciona a rodagem desta plataforma. */
  triggerPath: string;
  initialRuns: AdminRun[];
  initialRunningId: string | null;
  enabled: boolean;
  /** Mostrado só quando `enabled` é falso — explica por que está desligada e qual é o caminho vigente. */
  disabledNotice: ReactNode;
  /** Se true, exige checkbox de consentimento antes de acionar. */
  requiresConsent?: boolean;
  trialSingleProduct?: boolean;
}) {
  const fetch = useAdminFetch();
  const [runs, setRuns] = useState(initialRuns);
  const [runningId, setRunningId] = useState(initialRunningId);
  const [pages, setPages] = useAdminDraftState(`admin-panel.${marketplace}.pages`, 1);
  const [requesting, setRequesting] = useAdminDraftState(`admin-panel.${marketplace}.requesting`, false);
  const [awaitingSince, setAwaitingSince] = useAdminDraftState<number | null>(`admin-panel.${marketplace}.awaitingSince`, null);
  const [message, setMessage] = useAdminDraftState(`admin-panel.${marketplace}.message`, "");
  const [consented, setConsented] = useAdminDraftState(`admin-panel.${marketplace}.consented`, false);
  const [expandedGroups, setExpandedGroups] = useAdminDraftState<Set<string>>(`admin-panel.${marketplace}.expandedGroups`, () => new Set());
  const [knownIds, setKnownIds] = useAdminDraftState<string[]>(`admin-panel.${marketplace}.knownIds`, () => initialRuns.map((run) => run.id));
  const [activeBatchId, setActiveBatchId] = useAdminDraftState<string | null>(`admin-panel.${marketplace}.activeBatchId`, null);
  const [operationRunning, setOperationRunning] = useAdminDraftState(`admin-panel.${marketplace}.operationRunning`, false);

  const busy = operationRunning || runningId !== null || awaitingSince !== null;
  const canTrigger = requiresConsent ? consented : enabled;
  const groups = groupAdminRuns(runs);

  function toggleGroup(id: string) {
    setExpandedGroups((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function refresh(signal?: AbortSignal) {
    try {
      const response = await fetch(`/api/admin/rodagens?marketplace=${encodeURIComponent(marketplace)}`, { signal });
      const payload = (await response.json()) as RunsResponse;
      if (signal?.aborted || !payload.ok) return;
      const next = parseRuns(payload);
      setRuns(next);
      setRunningId(payload.runningId ?? null);
      if (activeBatchId) {
        const statusResponse = await fetch(`/api/admin/rodagem/lote?id=${encodeURIComponent(activeBatchId)}`, { signal });
        const statusPayload = await statusResponse.json();
        if (signal?.aborted) return;
        if (statusPayload.ok && statusPayload.batch) {
          const running = statusPayload.batch.status === "running";
          setOperationRunning(running);
          if (!running) {
            setAwaitingSince(null);
            setMessage(statusPayload.batch.status === "ok"
              ? "Captura concluída. Os fatos foram confirmados e seguem os critérios de curadoria."
              : "A rodagem terminou com pendências. Expanda os detalhes; as consultas concluídas ficam preservadas para retomada.");
            setActiveBatchId(null);
            return;
          }
        }
      }
      if (awaitingSince !== null) {
        const hasNew = payload.runningId || next.some((run) => !knownIds.includes(run.id));
        if (hasNew) {
          setAwaitingSince(null);
          setMessage("");
          setKnownIds(next.map((run) => run.id));
        } else if (Date.now() - awaitingSince > SPAWN_TIMEOUT_MS) {
          setAwaitingSince(null);
          setMessage("A rodagem foi solicitada, mas nenhuma execução nova apareceu em 30s. Verifique o processo no servidor.");
        }
      } else {
        setKnownIds(next.map((run) => run.id));
      }
    } catch {
      // rede local instável: o próximo tick tenta de novo
    }
  }

  useResumeAfterOperation(requesting, () => refresh());
  useEffect(() => {
    if (!busy) return;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    let inFlight = false;
    const isVisible = () => document.visibilityState !== "hidden";
    const poll = async () => {
      if (controller.signal.aborted || !isVisible() || inFlight) return;
      inFlight = true;
      await refresh(controller.signal);
      inFlight = false;
      if (!controller.signal.aborted && isVisible()) timer = setTimeout(() => void poll(), POLL_MS);
    };
    const resume = () => { clearTimeout(timer); void poll(); };
    void poll();
    document.addEventListener("visibilitychange", resume);
    return () => { controller.abort(); clearTimeout(timer); document.removeEventListener("visibilitychange", resume); };
    // A changed waiting marker restarts with current run IDs; only one read runs at a time.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [busy, awaitingSince, activeBatchId, marketplace, fetch]);

  async function trigger(resumeBatchId?: string) {
    if (requesting || busy || !canTrigger) return;
    setRequesting(true);
    setMessage("");
    try {
      const response = await fetch(triggerPath, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(resumeBatchId ? { action: "resume", batchId: resumeBatchId }
          : { pages: trialSingleProduct ? 1 : pages, consent: requiresConsent ? consented : undefined }),
      });
      const payload = (await response.json().catch(() => ({ ok: false }))) as {
        ok: boolean;
        error?: string;
        message?: string;
        batch?: { id: string; status: string };
      };
      if (response.status === 409) {
        const failureMessage = captureTriggerFailureMessage(response.status, payload);
        if (failureMessage) {
          setMessage(failureMessage);
        } else if (typeof payload.error === "string" && payload.error.endsWith("_capture_disabled")) {
          setMessage(payload.message ?? `A captura de ${marketplaceLabel} está desligada.`);
        } else {
          setMessage("Já existe uma rodagem em andamento.");
        }
        await refresh();
        return;
      }
      if (!response.ok || !payload.ok) {
        const failureMessage = captureTriggerFailureMessage(response.status, payload);
        if (failureMessage) {
          setMessage(failureMessage);
          return;
        }
        throw new Error(payload.error ?? "falha");
      }
      setActiveBatchId(payload.batch?.id ?? null);
      setOperationRunning(payload.batch?.status === "running");
      setAwaitingSince(Date.now());
      setMessage(resumeBatchId ? "Retomada solicitada. As consultas já concluídas serão reutilizadas."
        : "Rodagem solicitada. Aguardando o robô registrar a execução…");
    } catch {
      setMessage("Não foi possível acionar a rodagem. Veja o log do servidor web.");
    } finally {
      setRequesting(false);
    }
  }

  return (
    <section className="admin-section" aria-labelledby={`runs-title-${marketplace}`}>
      {busy && <div className="admin-pulse" role="status" aria-label="Rodagem em andamento"><i /></div>}
      <div className="admin-runs-head">
        <h2 id={`runs-title-${marketplace}`}>Rodagens · {marketplaceLabel}</h2>
        <div className="admin-trigger">
          {marketplace === "mercadolivre" ? (
            <a
              href="https://www.mercadolivre.com.br/ofertas"
              target="_blank"
              rel="noopener noreferrer"
              className="admin-trigger-open-link"
            >
              Abrir ofertas no Mercado Livre ↗
            </a>
          ) : (
            <>
              {requiresConsent && (
                <label className="admin-consent">
                  <input
                    type="checkbox"
                    checked={consented}
                    onChange={(event) => setConsented(event.target.checked)}
                    disabled={requesting || busy}
                  />
                  entendo os riscos de rodar automático
                </label>
              )}
              {trialSingleProduct ? <span>Ensaio: 1 consulta · até 1 produto</span> : <label>
                páginas
                <select value={pages} onChange={(event) => setPages(Number(event.target.value))} disabled={requesting || busy || !canTrigger}>
                  <option value={1}>1</option>
                  <option value={2}>2</option>
                  <option value={3}>3</option>
                </select>
              </label>}
              <button type="button" disabled={requesting || busy || !canTrigger} onClick={() => void trigger()}>
                {busy ? "rodagem em andamento…" : requesting ? "acionando…" : "nova rodagem ▸"}
              </button>
            </>
          )}
        </div>
      </div>
      {marketplace === "mercadolivre" && (
        <div className="admin-ml-guide-card">
          <div className="admin-ml-guide-header">
            <strong>Como capturar ofertas do Mercado Livre com a extensão:</strong>
          </div>
          <ol className="admin-ml-guide-steps">
            <li>
              <b>1. Baixe e ative a extensão:</b> No seu navegador (Opera, Chrome ou Edge), carregue a extensão BizuMiner descompactada.{" "}
              <a href="/admin?aba=captura-manual#devices-title">Ver dispositivos e pareamento →</a>
            </li>
            <li>
              <b>2. Abra o Mercado Livre:</b> Clique no botão <b>“Abrir ofertas no Mercado Livre ↗”</b> acima.
            </li>
            <li>
              <b>3. Importe com 1 clique:</b> Na página de ofertas aberta, clique no ícone da extensão BizuMiner e selecione <b>“Importar ofertas e continuar”</b>. Todos os produtos serão enviados diretamente para a triagem.
            </li>
          </ol>
        </div>
      )}
      {marketplace !== "mercadolivre" && !enabled && !consented && (
        <p className="admin-message admin-message--notice" role="status">
          {disabledNotice}
        </p>
      )}
      {marketplace !== "mercadolivre" && !enabled && consented && (
        <p className="admin-message admin-message--ok" role="status">
          Rodagem habilitada por consentimento. O robô será acionado ao clicar em "nova rodagem".
        </p>
      )}
      {message && <p className="admin-message" role="status">{message}</p>}
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>status</th>
              <th>início</th>
              <th>duração</th>
              <th className="num">buscas</th>
              <th className="num">itens</th>
              <th className="num">novos</th>
              <th className="num">mudanças de preço</th>
            </tr>
          </thead>
          <tbody>
            {groups.length === 0 && (
              <tr><td colSpan={7} className="admin-table-empty">Nenhuma rodagem registrada ainda.</td></tr>
            )}
            {groups.map((group) => {
              const status = statusLabel(group.status, group.itemsCaptured);
              const expanded = expandedGroups.has(group.id);
              const detailsId = `run-group-${group.children[0]!.id}`;
              return (
                <Fragment key={group.id}>
                  <tr className={`admin-run-group-row${status.className === "empty" ? " row-empty" : ""}${expanded ? " is-expanded" : ""}`}>
                    <td className="admin-run-status-cell">
                      <button
                        type="button"
                        className="admin-run-toggle"
                        aria-expanded={expanded}
                        aria-controls={detailsId}
                        aria-label={`${expanded ? "Recolher" : "Expandir"} detalhes da rodagem de ${dateTime(group.startedAt)}`}
                        onClick={() => toggleGroup(group.id)}
                      >
                        <span aria-hidden="true">›</span>
                      </button>
                      <span className={`run-status ${status.className}`}>{status.label}</span>
                    </td>
                    <td>
                      <b className="admin-run-date">{dateTime(group.startedAt)}</b>
                      <small className="admin-run-plan">{group.planId ?? "rodagem avulsa"}</small>
                    </td>
                    <td className="num">{duration(group)}</td>
                    <td className="num"><b>{group.searchCount}</b></td>
                    <td className="num">{group.itemsCaptured}</td>
                    <td className="num">{group.itemsNew}</td>
                    <td className="num">{group.priceChanges}</td>
                  </tr>
                  {expanded && group.children.map((run, index) => {
                    const childStatus = statusLabel(run.status, run.itemsCaptured);
                    const title = run.targetCategory ?? run.queryId ?? "Consulta avulsa";
                    const detailParts = [
                      run.keyword ? `“${run.keyword}”` : null,
                      run.targetFamily ? `família ${run.targetFamily}` : null,
                      `${run.observationCount} observações`,
                      run.pagesRead !== null ? `${run.pagesRead} pág.` : null,
                      run.itemsSkippedByPolicy ? `${run.itemsSkippedByPolicy} limitados` : null,
                      run.saturationDetected ? `saturada${run.dominantFamily ? `: ${run.dominantFamily}` : ""}` : null,
                    ].filter(Boolean).join(" · ");
                    return (
                      <Fragment key={run.id}>
                        <tr id={index === 0 ? detailsId : undefined} className="admin-run-child-row">
                          <td><span className={`run-status ${childStatus.className}`}>{childStatus.label}</span></td>
                          <td>
                            <b className="admin-run-query">{title}</b>
                            <small className="admin-run-child-time">{dateTime(run.startedAt)}</small>
                          </td>
                          <td className="num">{duration(run)}</td>
                          <td className="num"><span className="admin-run-mode">{modeLabel(run.mode)}</span></td>
                          <td className="num">{run.itemsCaptured}</td>
                          <td className="num">{run.itemsNew}</td>
                          <td className="num">{run.priceChanges}</td>
                        </tr>
                        {(detailParts || run.error) && (
                          <tr className="admin-run-child-detail">
                            <td aria-hidden="true" />
                            <td colSpan={6}>
                              {detailParts && <span>{detailParts}</span>}
                              {run.error && <strong>{run.error}</strong>}
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    );
                  })}
                  {expanded && marketplace === "shopee" && !trialSingleProduct
                    && (group.status === "partial" || group.status === "error")
                    && group.children[0]?.operationBatchId && (
                    <tr className="admin-run-child-detail"><td colSpan={7}>
                      <p>As consultas concluídas ficam preparadas até a captura terminar. A retomada reutiliza esses resultados e tenta as consultas pendentes.</p>
                      <div className="admin-trigger"><button type="button" disabled={requesting || busy || !canTrigger}
                        onClick={() => void trigger(group.children[0]!.operationBatchId!)}>Retomar consultas pendentes</button></div>
                    </td></tr>
                  )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="admin-footnote">
        Uma rodagem reúne todas as buscas disparadas no mesmo plano. Expanda a linha para investigar consultas, saturação e erros.
        Rodagem <b>vazia</b> (0 itens com status ok) é sinal de captura quebrada em silêncio.
      </p>
    </section>
  );
}
