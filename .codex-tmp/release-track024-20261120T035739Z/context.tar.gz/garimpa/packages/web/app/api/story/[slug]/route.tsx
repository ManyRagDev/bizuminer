import {offerArtworkFacts} from "../../../../lib/offer-artwork.ts";
import { confirmedOfferDetail } from "../../../../lib/confirmed-offer-db.ts";
import { ImageResponse } from "next/og";
import type { NextRequest } from "next/server";
import { dealDetail } from "../../../../lib/db";
import { MINIMUM_HISTORY, priceFreshness, priceHighlight } from "../../../../lib/deal-signal";
import { marketplaceDef } from "../../../../lib/marketplaces";
import { fetchProductImage, ogFonts } from "../../../../lib/og-assets";
import { toVitrineProduct } from "../../../../lib/deal-view";
import { formatOfferMoney, offerPriceLabel } from "../../../../lib/offer-price";
import { storyLinkLabel } from "../../../../lib/story-link";
import { checkAffiliateUser } from "../../../../lib/api-auth";
import { readLivePauta } from "../../../../lib/pauta-db";

export const preferredRegion = "gru1";

export const runtime = "nodejs";

/**
 * Arte pronta para o status do WhatsApp: 1080×1920 gerada no servidor a partir
 * dos dados que já temos do produto.
 *
 * POR QUE EXISTE
 *
 * Postar um produto no status hoje custa ~90s de trabalho manual (print,
 * recorte, editor, digitar preço, colar link). Não há como automatizar a
 * postagem — nem a API oficial do WhatsApp (Cloud API) expõe endpoint de
 * Status; nenhuma via legítima expõe. O que dá para eliminar é a PREPARAÇÃO.
 * Com a arte pronta, o fluxo vira `navigator.share({ files })` a partir do
 * celular: Compartilhar → WhatsApp → Meu status.
 *
 * É a mesma família do card OG de `/bizu/[slug]`, com três diferenças que vêm
 * do meio, não de gosto: retrato em vez de paisagem, área segura (abaixo) e o
 * link impresso na própria imagem.
 */
const SIZE = { width: 1080, height: 1920 };

/**
 * ÁREA SEGURA DO STATUS
 *
 * O WhatsApp desenha por cima da imagem: no topo a barra de progresso e o
 * autor (~240px), embaixo a legenda e o campo "responder" (~320px). Conteúdo
 * colocado nessas faixas é coberto — e o que some primeiro é justamente o
 * preço ou o link, que é o que precisa ser lido.
 *
 * Margens com folga sobre a medida real porque a altura da sobreposição varia
 * com o aparelho (notch, barra de gestos) e com a versão do app. Perder 100px
 * de imagem custa nada; perder o link custa a conversão inteira.
 */
const SAFE_TOP = 300;
const SAFE_BOTTOM = 380;
const SIDE = 72;

// Paleta fixa (tema claro de globals.css): a arte é uma imagem estática, sem
// contexto de tema de quem vê — usa sempre a identidade de superfície clara.
const PAPER = "#f3f0e8";
const PAPER_DEEP = "#e6e0d3";
const SURFACE_BRIGHT = "#ffffff";
const INK = "#151515";
const INK_MUTED = "#5f5c55";
const INK_QUIET = "#6b6b6b";
const BLUE = "#2563eb";
const BLUE_TEXT = "#1d4ed8";
const LINE = "rgba(21, 21, 21, 0.18)";

export async function GET(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const privateArtwork = request.nextUrl.searchParams.get("pauta") === "1";
  const option = request.nextUrl.searchParams.get("opcao");
  const noStore = { "Cache-Control": "private, no-store" };
  let product;
  if (privateArtwork) {
    const check = await checkAffiliateUser(request);
    if (check.kind !== "ok") return new Response(null, { status: check.kind === "no_session" ? 401 : 403, headers: noStore });
    const pauta = await readLivePauta(check.context, "stories", null);
    product = pauta.products.find(p => p.id === slug && p.shareTarget.kind === "pauta");
    if (!product) return new Response("Oferta indisponível neste canal", { status: 404, headers: noStore });
  } else if (option) {
    product = (await confirmedOfferDetail(slug, option))?.product;
    if (!product) return new Response("Opção expirada ou indisponível", { status: 404, headers: noStore });
  } else {
    const detail = await dealDetail(slug);
    if (detail) product = toVitrineProduct(detail.deal);
  }
  if (!product) return new ImageResponse(<Fallback />, { ...SIZE, fonts: await ogFonts(),headers:{"Cache-Control":"no-store"} });
  const stale = priceFreshness(product.evidenceObservedAt) === "stale";
  const title = product.displayTitle ?? product.title;
  const facts=offerArtworkFacts(product);
  const highlight = priceHighlight({
    ...product,
    lowestVerified: product.lowestVerified && product.historyDays >= MINIMUM_HISTORY.days
      && product.observationCount >= MINIMUM_HISTORY.observations,
  });
  // Mesma regra do card OG: "ainda sem histórico" é selo negativo, e um selo
  // negativo numa peça de divulgação só ocupa espaço. Silêncio é o padrão.
  const badge = stale || product.priceType !== "exact" || (product.currency && product.currency !== "BRL") || highlight?.tone === "unproven" ? null : highlight;
  const [photo, fonts] = await Promise.all([fetchProductImage(product.imageUrl), ogFonts()]);
  if (product.offerValidUntil && !(Date.parse(product.offerValidUntil)>Date.now()))
    return new Response("Oferta expirada",{status:410,headers:noStore});
  // Image assets may take long enough for facts, eligibility or channel
  // configuration to change. Re-read before returning the prepared artwork.
  let current:typeof product | undefined;
  if(privateArtwork) {
    const check=await checkAffiliateUser(request);
    if(check.kind!=="ok") return new Response("Sessão indisponível",{status:403,headers:noStore});
    current=(await readLivePauta(check.context,"stories",null)).products.find(p=>p.id===slug && p.shareTarget.kind==="pauta");
  } else if(option) current=(await confirmedOfferDetail(slug,option))?.product;
  else {
    const detail=await dealDetail(slug);
    current=detail ? toVitrineProduct(detail.deal) : undefined;
  }
  const artworkFacts=(item:NonNullable<typeof product>)=>JSON.stringify([
    item.id,item.title,item.displayTitle,item.marketplace,item.imageUrl,item.priceCents,item.priceType,item.currency,
    item.priceMinCents,item.priceMaxCents,item.originalPriceCents,item.originalPriceKind,item.offerOptionKey,
    item.purchaseContents,item.offerConditions,item.evidenceObservedAt,item.offerValidUntil,item.lowestVerified,
    item.historyDays,item.observationCount,item.previousMinPriceCents,
  ]);
  if(!current || artworkFacts(current)!==artworkFacts(product)
    || current.offerValidUntil && !(Date.parse(current.offerValidUntil)>Date.now()))
    return new Response("Oferta precisa de nova conferência",{status:410,headers:noStore});
  const marketplace = marketplaceDef(product.marketplace);
  const stamp = marketplace
    ? { label: marketplace.stampLabel, style: marketplace.stampStyle }
    : { label: product.marketplace, style: "outlined" as const };

  const hasReference = !stale && (product.currency ?? "BRL") === "BRL" && product.originalPriceKind === "source_claimed" && product.priceType === "exact" && product.originalPriceCents !== null && product.originalPriceCents > product.priceCents;

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: `${SAFE_TOP}px ${SIDE}px ${SAFE_BOTTOM}px`,
          backgroundColor: PAPER,
          fontFamily: "Manrope",
        }}
      >
        {/* Marca à esquerda, origem à direita: a loja é lida ANTES do título.
            Mesmo carimbo do site — preenchido para o Mercado Livre, vazado
            para a Shopee — e a diferença é estrutural, nunca de cor, porque
            aqui a cor já significa confiança. */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", fontSize: 46, fontWeight: 800, letterSpacing: "-0.03em", color: INK }}>
            Bizu<span style={{ color: BLUE_TEXT }}>Miner</span>
          </div>
          <div
            style={{
              display: "flex",
              padding: "12px 20px",
              fontSize: 26,
              fontWeight: 700,
              letterSpacing: "0.04em",
              textTransform: "uppercase",
              // Preenchido / vazado / tracejado: três degraus ESTRUTURAIS, nunca
              // de matiz. Aqui a cor já significa confiança (azul = evidência
              // nossa), e diferença tonal não sobreviveria nem ao daltonismo nem
              // à inversão de tema. Renderizar `dashed` como sólido colapsaria a
              // AliExpress na Shopee — as duas viram "vazado" e o carimbo mente.
              border: `3px ${stamp.style === "dashed" ? "dashed" : "solid"} ${INK}`,
              backgroundColor: stamp.style === "filled" ? INK : SURFACE_BRIGHT,
              color: stamp.style === "filled" ? SURFACE_BRIGHT : INK,
            }}
          >
            {stamp.label}
          </div>
        </div>

        <div
          style={{
            display: "flex",
            width: "100%",
            height: 760,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: SURFACE_BRIGHT,
            border: `1px solid ${LINE}`,
          }}
        >
          {photo ? (
            <img src={photo} width={680} height={680} style={{ objectFit: "contain" }} />
          ) : (
            <div
              style={{
                display: "flex",
                width: 260,
                height: 260,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: PAPER_DEEP,
                fontSize: 120,
                fontWeight: 800,
                color: BLUE_TEXT,
              }}
            >
              B
            </div>
          )}
        </div>

        <div style={{ display: "flex", flexDirection: "column" }}>
          {badge && (
            <div
              style={{
                display: "flex",
                alignSelf: "flex-start",
                marginBottom: 24,
                padding: "12px 20px",
                fontSize: 28,
                fontWeight: 600,
                letterSpacing: "0.02em",
                textTransform: "uppercase",
                border: `3px solid ${BLUE}`,
                color: badge.tone === "verified" ? SURFACE_BRIGHT : BLUE_TEXT,
                backgroundColor: badge.tone === "verified" ? BLUE : SURFACE_BRIGHT,
              }}
            >
              {badge.label}
            </div>
          )}
          <div
            style={{
              display: "flex",
              fontSize: title.length <= 100 ? 44 : title.length <= 180 ? 36 : title.length <= 300 ? 28 : 22,
              fontWeight: 800,
              lineHeight: 1.1,
              letterSpacing: "-0.02em",
              color: INK,
            }}
          >
            {title}
          </div>
          {facts.contents && <div style={{display:"flex",marginTop:18,fontSize:28,lineHeight:1.2,color:INK_QUIET}}>{facts.contents}</div>}
          {facts.conditions && <div style={{display:"flex",marginTop:12,fontSize:26,lineHeight:1.2,color:INK_QUIET}}>{facts.conditions}</div>}
        </div>

        <div style={{ display: "flex", flexDirection: "column" }}>
          {hasReference && (
            <div style={{ display: "flex", fontSize: 34, fontWeight: 600, color: INK_QUIET }}>
              Preço de referência no anúncio: {formatOfferMoney(product.originalPriceCents!, product.currency || "BRL")}
            </div>
          )}
          {stale && <div style={{ display: "flex", fontSize: 26, color: INK_MUTED }}>Última captura · confira o preço atual</div>}
          <div style={{ display: "flex", marginTop: 4, fontSize: offerPriceLabel(product).length > 18 ? 54 : 104, fontWeight: 800, letterSpacing: "-0.03em", color: INK }}>
            {offerPriceLabel(product)}
          </div>

          {/* O LINK IMPRESSO NA ARTE
              A legenda do status leva o link clicável, mas o WhatsApp às vezes
              descarta o texto quando o compartilhamento traz arquivo. Se isso
              acontecer e o link só existir na legenda, o story fica bonito e
              inútil. Impresso aqui ele sempre existe — e como ninguém copia
              texto de imagem, precisa ser curto o bastante para ser DIGITADO. */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginTop: 28,
              paddingTop: 24,
              borderTop: `1px solid ${LINE}`,
            }}
          >
            <div style={{ display: "flex", fontSize: 40, fontWeight: 800, letterSpacing: "-0.01em", color: BLUE_TEXT }}>
              {privateArtwork ? "Veja a oferta pelo link" : storyLinkLabel()}
            </div>
            <div style={{ display: "flex", fontSize: 24, fontWeight: 600, color: INK_MUTED }}>
              link de afiliado
            </div>
          </div>
        </div>
      </div>
    ),
    { ...SIZE, fonts, headers:privateArtwork ? noStore : {"Cache-Control":"no-store"} },
  );
}

/** Produto inexistente: a arte não quebra, vira capa da marca. */
function Fallback() {
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: PAPER,
        fontFamily: "Manrope",
      }}
    >
      <div style={{ display: "flex", fontSize: 96, fontWeight: 800, letterSpacing: "-0.04em", color: INK }}>
        Bizu<span style={{ color: BLUE_TEXT }}>Miner</span>
      </div>
      <div style={{ display: "flex", marginTop: 28, fontSize: 36, fontWeight: 600, color: INK_MUTED }}>
        Um bizu bom vale ouro.
      </div>
    </div>
  );
}
