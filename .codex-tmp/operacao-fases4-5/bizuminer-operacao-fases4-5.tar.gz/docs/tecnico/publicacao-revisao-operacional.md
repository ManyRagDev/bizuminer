# Pacote de publicação da revisão operacional — fases 1–5

Estado: preparação local. Não houve push, deploy, migração remota, captura em loja, chamada paga nem envio a clientes nesta entrega. O pacote é produzido por `tools/editorial-tests/package-operation-release.py` em `.codex-tmp/operacao-fases4-5/`, depois da homologação registrada em `docs/implementation/evidencias/operacao-fases4-5.json`.

O arquivo `bizuminer-operacao-fases4-5.tar.gz` contém os componentes atuais e o `release-manifest.json`. O manifesto identifica HEAD, **também inclui as alterações locais e arquivos novos**, registra SHA-256 de cada arquivo e o BUILD_ID verificado. `receipt.json` identifica o hash do próprio arquivo. Não se deve representar esse checkout apenas pelo commit HEAD. O pacote inclui fonte completo dos componentes afetados e referências/testes; não inclui `.env`, segredos, node_modules, cache Next, dados do banco, sessões de teste nem imagens de outros aplicativos. É um pacote de fonte verificável, não uma imagem pronta com configuração de produção.

## Componentes e compatibilidade

| Componente | Conteúdo / motivo |
| --- | --- |
| `garimpa-web` | Hoje, menu, configurações, contexto de conta, Capturas, Curadoria, Pauta e leitores operacionais. O build importa código dos pacotes capture e persistence. |
| `garimpa-capture-executor` | O listener `packages/web/bin/listen-capture-batches.ts` importa o worker de atributos, alterado na fase 3 para diagnóstico sanitizado e limite observado. Recompilar o consumidor com a mesma revisão, conservando sua configuração e autorização atuais. |
| Banco | Três expansões abaixo, além dos pré-requisitos reais já instalados. |
| Extensão | Não precisa de atualização para usar esta revisão. Versão 1 do contrato, requestId, fingerprint e pareamento continuam válidos. A fonte é incluída para identificação; não instalar uma versão como efeito deste pacote. |

Expansões diretamente exigidas por este objetivo, em ordem:

1. `20261115234320_capture_activity_history.sql`: acesso de leitura ao histórico de recibos, identidade invocadora e índices.
2. `20261116195549_curation_operation_diagnostic.sql`: diagnóstico opcional, índice de histórico e limite observado do orçamento.
3. `20261117003000_curation_operation_reader.sql`: projeção de leitura para dono/operador. Mantém o job bruto e a auditoria/liberação sob as permissões anteriores; não expõe prompt, input_snapshot, resposta de modelo, fingerprint ou worker id.

O leitor para operador acusa indisponibilidade se a terceira expansão estiver ausente; não representa jobs invisíveis como zero. O dono conserva leitura compatível durante a transição. A projeção usa os privilégios do dono da view, com `security_barrier`, validação de conta/membership/role ativa em cada linha e apenas SELECT para `garimpa_app`; conferir proprietário e privilégios dos helpers no destino. Nenhuma nova permissão pública é necessária.

## Aplicação no destino, quando autorizada

1. Identificar o destino autorizado, revisão e digests **atuais** de web/executor, schema/migrações aplicadas e extensão instalada. Comparar o manifesto completo do pacote com essa revisão; este checkout contém alterações anteriores à revisão operacional. Não aplicar todo o catálogo de migrations indiscriminadamente.
2. Registrar backup recuperável e os digests de retorno antes da mudança. Conferir que os três workflows continuam desativados, sem execuções pendentes. A suspensão foi determinada pelo dono em 15/11/2026 e não é revogada por publicação.
3. Ensaiar apenas as expansões pendentes sobre cópia compatível do schema real, incluindo proprietários e ACLs do destino. Aplicar expansão antes dos leitores que a exigem, com limite de espera/timeout e recibo da transação. Não executar backfill que invente associação histórica, resultado de job ou limite de orçamento.
4. Reconstruir web e executor a partir do mesmo snapshot, com as dependências travadas e a configuração existente do destino. Não transportar URLs/Auth de fixture, arquivos `.env` de teste ou BUILD_ID como credencial de produção. A publicação é restrita aos dois serviços BizuMiner; PostSpark, DNS, infraestrutura e outros aplicativos ficam fora do escopo.
5. Preservar cotas, flags, allowlists e todos os agendamentos suspensos. Não habilitar workflow, `schedule`, worker alternativo ou captura externa para demonstrar a interface. O executor já autorizado mantém suas proteções contra efeitos incertos.
6. Homologar por leitura autenticada: Hoje, conta e timestamp; localizar recibo/lote existente; abrir detalhe e item; retornar ao filtro; comparar Curadoria e Pauta nos dois canais; operador/conta alheia/vínculo revogado; mobile e recarga. Não liberar os resultados incertos reais como teste. Captura ou chamada externa adicional exige autorização para aquela operação/destino.
7. Registrar aplicação e aceite remoto separadamente da homologação local, incluindo estado dos workflows. A confirmação humana de autonomia deve registrar o que ainda exigiu chat, distinguindo defeito de informação de intervenção administrativa legítima.

## Retorno seguro

Se falhar a homologação, restaurar **os digests anteriores identificados na etapa 1** de web e executor, mantendo colunas/view/índices aditivos e todos os recibos, observações, avaliações, jobs, limites consumidos e confirmações. Não usar down migration destrutiva, reset de orçamento, nova captura ou liberação coletiva como retorno. Não reativar produtor legado nem agendamentos.

Conferir compatibilidade das imagens anteriores com as expansões conservadas e as gravações ocorridas durante a janela. Uma restauração de banco seria outra operação, com impacto próprio e autorização específica; não é a reversão normal desta publicação. A view de leitura pode permanecer sem ser usada pelos leitores anteriores. Após o retorno, repetir login e consultas de conta/histórico/pauta e registrar o resultado.

## Limites da homologação local

PostgreSQL 17.12 nativo descartável e Next real foram utilizados com papéis de runtime restritos. O SDK Supabase instalado operou contra Auth sintético em loopback; isso não valida o Supabase hospedado, pooler, domínio, lojas ou modelo externos. Avaliações e dados comerciais foram sintéticos. Concorrência de banco, rollback e confirmação idempotente foram testados em sessões independentes; a observação do browser também tem testes com relógio virtual para falha, aba oculta, espera e resposta tardia. Mobile foi verificado por viewport/DOM, dimensões dos controles e teclado; não foi um aparelho físico. O pacote não é aceite remoto nem comprovação de operação autônoma permanente.
