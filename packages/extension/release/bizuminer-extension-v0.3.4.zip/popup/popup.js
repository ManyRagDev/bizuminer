"use strict";
(() => {
  // src/lib/storage.ts
  var BUILD_API_ORIGIN = true ? "https://www.bizuminer.com.br" : "https://www.bizuminer.com.br";
  if (!["https://www.bizuminer.com.br", "http://localhost:3100"].includes(BUILD_API_ORIGIN)) throw new Error("invalid_build_origin");
  var STORAGE_KEYS = {
    token: "bm_token",
    deviceId: "bm_device_id",
    affiliateName: "bm_affiliate_name",
    activeTabId: "bm_active_tab_id",
    outbox: "bm_outbox",
    apiBaseUrl: "bm_api_base_url",
    sessionOrigin: "bm_session_origin"
  };
  function chromeStorage() {
    return chrome.storage.local;
  }
  async function getToken(storage) {
    const data = await storage.get([STORAGE_KEYS.token, STORAGE_KEYS.deviceId, STORAGE_KEYS.sessionOrigin]);
    const token = data[STORAGE_KEYS.token];
    return typeof token === "string" && token.startsWith("bm_ext_") && data[STORAGE_KEYS.sessionOrigin] === BUILD_API_ORIGIN && typeof data[STORAGE_KEYS.deviceId] === "string" && !!data[STORAGE_KEYS.deviceId] ? token : null;
  }

  // src/popup/popup.ts
  var EXPECTED_ORIGIN = true ? "https://www.bizuminer.com.br" : "https://www.bizuminer.com.br";
  var statusLine = document.querySelector(".status-line");
  var statusText = document.querySelector("#status-text");
  var pendingEl = document.querySelector("#pending");
  var clearFailed = document.querySelector("#clear-failed");
  var activateBtn = document.querySelector("#activate");
  var pairingSection = document.querySelector("#pairing");
  var codeInput = document.querySelector("#code");
  var pairBtn = document.querySelector("#pair");
  var logoutBtn = document.querySelector("#logout");
  var envOrigin = document.querySelector("#env-origin");
  var batchPrepare = document.querySelector("#batch-prepare");
  var batchImport = document.querySelector("#batch-import");
  var batchCancel = document.querySelector("#batch-cancel");
  var batchResult = document.querySelector("#batch-result");
  var originVerified = false;
  var accountConnected = false;
  var errors = {
    not_paired: "Conecte este navegador \xE0 sua conta antes de importar.",
    session_changed: "A conta ou o destino mudou. Descarte esta leitura e leia a p\xE1gina novamente.",
    invalid_url: "O destino n\xE3o corresponde a esta vers\xE3o. Instale a vers\xE3o correta e conecte novamente.",
    invalid_sender: "Abra o popup oficial da extens\xE3o para confirmar esta a\xE7\xE3o.",
    device_revoked: "O acesso deste navegador foi revogado. Conecte novamente pelo painel.",
    unauthorized: "O acesso expirou ou foi revogado. Conecte novamente pelo painel.",
    forbidden: "A conta n\xE3o tem permiss\xE3o para importar estes produtos.",
    account_suspended: "A conta est\xE1 suspensa. Confira o acesso no painel.",
    capture_expired: "Esta leitura venceu. Descarte-a e leia os produtos novamente.",
    retry_limit: "O limite de tentativas foi atingido. Confira o painel e descarte esta leitura antes de uma nova captura.",
    queue_full: "A fila est\xE1 cheia. Confira os envios pendentes e descarte os interrompidos antes de continuar.",
    offers_page_required: "Abra uma oferta ou listagem no Mercado Livre, Amazon Brasil ou AliExpress.",
    ml_page_required: "Abra uma oferta ou listagem no Mercado Livre, Amazon Brasil ou AliExpress.",
    no_offers: "Nenhum produto completo foi encontrado. Aguarde a p\xE1gina terminar de carregar.",
    marketplace_server_outdated: "O servidor ainda n\xE3o aceita esta importa\xE7\xE3o. Confira a atualiza\xE7\xE3o do painel.",
    marketplace_capture_unavailable: "A importa\xE7\xE3o desta loja n\xE3o est\xE1 habilitada nesta conta.",
    invalid_payload: "O servidor recusou os dados. Descarte esta leitura e confira a p\xE1gina antes de tentar novamente.",
    browser_capture_forbidden: "Este navegador n\xE3o tem permiss\xE3o para importar na conta.",
    prepare_first: "Leia os produtos da p\xE1gina antes de confirmar a importa\xE7\xE3o.",
    invalid_code: "C\xF3digo inv\xE1lido ou expirado. Gere outro no painel desta conta.",
    pairing_code_invalid: "C\xF3digo inv\xE1lido ou expirado. Gere outro no painel desta conta.",
    exchange_failed: "N\xE3o foi poss\xEDvel conectar. Confira o c\xF3digo e o destino mostrado abaixo.",
    network: "N\xE3o houve confirma\xE7\xE3o do servidor. O envio preserva a mesma identifica\xE7\xE3o para evitar duplica\xE7\xE3o.",
    timeout: "O servidor n\xE3o confirmou a tempo. O envio preserva a mesma identifica\xE7\xE3o para evitar duplica\xE7\xE3o.",
    invalid_response: "A resposta do servidor n\xE3o p\xF4de ser confirmada. Confira o painel.",
    storage_or_network: "N\xE3o foi poss\xEDvel concluir a a\xE7\xE3o. Confira a conex\xE3o e abra a extens\xE3o novamente."
  };
  var explain = (error) => errors[error ?? ""] ?? "A solicita\xE7\xE3o foi recusada. Confira o acesso e a vers\xE3o do painel.";
  function notice(message, kind = "normal") {
    if (!batchResult) return;
    batchResult.className = `hint${kind === "normal" ? "" : ` batch-${kind}-notice`}`;
    batchResult.textContent = message;
  }
  function disconnected(message) {
    accountConnected = false;
    statusLine?.classList.remove("connected");
    statusLine?.classList.add("disconnected");
    if (statusText) statusText.textContent = message;
  }
  async function refreshStatus(preserveNotice = false) {
    try {
      const env = await chrome.runtime.sendMessage({ type: "GET_ENV" });
      originVerified = env?.baseUrl === EXPECTED_ORIGIN && env.allowedBaseUrls?.length === 1 && env.allowedBaseUrls[0] === EXPECTED_ORIGIN;
      if (envOrigin) envOrigin.textContent = EXPECTED_ORIGIN;
      if (!originVerified) {
        disconnected("Destino incompat\xEDvel. Atualize a extens\xE3o.");
        if (batchPrepare) batchPrepare.disabled = true;
        if (batchImport) batchImport.disabled = true;
        if (pairBtn) pairBtn.disabled = true;
        return;
      }
      const pending = await chrome.runtime.sendMessage({ type: "PENDING" });
      const state = await chrome.runtime.sendMessage({ type: "GET_BATCH_STATE" });
      const token = await getToken(chromeStorage());
      accountConnected = Boolean(token);
      const data = await chromeStorage().get("bm_affiliate_name");
      const name = typeof data.bm_affiliate_name === "string" ? data.bm_affiliate_name : "";
      statusLine?.classList.toggle("connected", Boolean(token));
      statusLine?.classList.toggle("disconnected", !token);
      if (statusText) statusText.textContent = token ? name || "Conectado \xE0 sua conta" : "Conecte este navegador";
      if (pairingSection) pairingSection.hidden = Boolean(token);
      if (logoutBtn) logoutBtn.hidden = !token;
      if (batchPrepare) batchPrepare.disabled = !token;
      if (batchImport) batchImport.disabled = !token;
      if (pairBtn) pairBtn.disabled = false;
      const active = pending.pending ?? 0, failed = pending.failed ?? 0;
      if (pendingEl) {
        pendingEl.hidden = active + failed === 0;
        pendingEl.textContent = [
          active > 0 ? `${active} envio(s) aguardando confirma\xE7\xE3o.` : "",
          failed > 0 ? `${failed} envio(s) interrompido(s), sem novas tentativas autom\xE1ticas. ${explain(pending.errors?.[0])}` : ""
        ].filter(Boolean).join(" ");
      }
      if (clearFailed) clearFailed.hidden = failed === 0;
      if (batchCancel) batchCancel.hidden = !state.hasBatch;
      if (batchImport) {
        batchImport.hidden = !state.hasBatch || Boolean(state.stopped);
        batchImport.textContent = state.queued ? "Tentar enviar agora" : `Importar ${state.count ?? ""} produtos para revis\xE3o`;
      }
      if (state.hasBatch && state.stopped) {
        notice(`Envio interrompido. ${explain(state.lastError)} N\xE3o haver\xE1 novas tentativas autom\xE1ticas.`, "stopped");
      } else if (state.hasBatch && state.queued) {
        notice(`${state.count ?? ""} produtos aguardando confirma\xE7\xE3o. Haver\xE1 tentativas limitadas enquanto esta leitura for v\xE1lida. ${state.lastError ? explain(state.lastError) : ""}`, "queued");
      } else if (state.hasBatch && !preserveNotice) {
        notice(`${state.count ?? ""} produtos lidos. Confirme a importa\xE7\xE3o para revis\xE3o na sua conta.`);
      }
    } catch {
      disconnected("N\xE3o foi poss\xEDvel consultar a extens\xE3o. Abra novamente.");
    }
  }
  activateBtn?.addEventListener("click", async () => {
    if (!originVerified) return;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content/activate-catalog.js"] });
      window.close();
    } catch {
      notice("Esta p\xE1gina n\xE3o permite ativa\xE7\xE3o. Abra uma p\xE1gina de produtos compat\xEDvel.");
    }
  });
  pairBtn?.addEventListener("click", async () => {
    if (!originVerified) return;
    const code = (codeInput?.value ?? "").trim().toUpperCase();
    if (!code) return;
    pairBtn.disabled = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: "PAIR", pairingCode: code });
      if (result.ok) {
        if (codeInput) codeInput.value = "";
        await refreshStatus();
      } else {
        await refreshStatus(true);
        disconnected(explain(result.error));
      }
    } catch {
      disconnected("N\xE3o foi poss\xEDvel conectar. Confira a conex\xE3o e o c\xF3digo do painel.");
    } finally {
      pairBtn.disabled = !originVerified;
    }
  });
  logoutBtn?.addEventListener("click", async () => {
    try {
      await chrome.runtime.sendMessage({ type: "LOGOUT" });
      await refreshStatus();
    } catch {
      disconnected("N\xE3o foi poss\xEDvel sair. Abra a extens\xE3o novamente.");
    }
  });
  clearFailed?.addEventListener("click", async () => {
    clearFailed.disabled = true;
    try {
      await chrome.runtime.sendMessage({ type: "CLEAR_FAILED" });
      await refreshStatus();
    } catch {
      disconnected("N\xE3o foi poss\xEDvel descartar os envios interrompidos.");
    } finally {
      clearFailed.disabled = false;
    }
  });
  batchCancel?.addEventListener("click", async () => {
    batchCancel.disabled = true;
    try {
      await chrome.runtime.sendMessage({ type: "CANCEL_BATCH" });
      notice("Leitura descartada neste navegador. Produtos j\xE1 recebidos continuam no painel.");
      await refreshStatus(true);
    } catch {
      notice("N\xE3o foi poss\xEDvel descartar esta leitura.", "stopped");
    } finally {
      batchCancel.disabled = false;
    }
  });
  batchPrepare?.addEventListener("click", async () => {
    if (!originVerified) return;
    batchPrepare.disabled = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: "PREPARE_BATCH" });
      if (!result.ok) notice(explain(result.error), result.stopped ? "stopped" : "normal");
      else {
        const d = result.diagnostics;
        const details = d ? [
          `${d.products} an\xFAncios identificados`,
          d.noPrice && `${d.noPrice} sem pre\xE7o detectado${d.visibleNoPrice ? ` (${d.visibleNoPrice} vis\xEDveis na tela)` : ""}`,
          d.uncertainPrice && `${d.uncertainPrice} com pre\xE7o indefinido`,
          d.noTitle && `${d.noTitle} sem nome`
        ].filter(Boolean).join(" \xB7 ") : "";
        const sample = result.sample;
        const money = (cents) => (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
        const samplePrice = sample?.priceType === "range" && sample.priceMaxCents ? `${money(sample.priceCents)} a ${money(sample.priceMaxCents)}` : sample ? `${sample.priceType === "from" ? "a partir de " : ""}${money(sample.priceCents)}` : "";
        notice(`${result.count} produtos ${result.preserved ? "da leitura anterior preservados" : "prontos para conferir"}.` + (details ? ` ${details}.` : "") + (sample ? ` Exemplo: ${sample.title.slice(0, 85)} \u2014 ${samplePrice}.` : ""));
      }
      await refreshStatus(true);
    } catch {
      notice("N\xE3o foi poss\xEDvel ler esta p\xE1gina. Confira a p\xE1gina aberta.");
    } finally {
      batchPrepare.disabled = !originVerified || !accountConnected;
    }
  });
  batchImport?.addEventListener("click", async () => {
    if (!originVerified) return;
    batchImport.disabled = true;
    notice("Enviando os produtos confirmados para revis\xE3o\u2026");
    try {
      const result = await chrome.runtime.sendMessage({ type: "IMPORT_BATCH" });
      if (result.ok && !result.queued) notice(`${result.importedCount ?? ""} produtos recebidos para revis\xE3o. Confira a curadoria no painel.`, "success");
      else if (!result.ok) notice(explain(result.error), "stopped");
      await refreshStatus(true);
    } catch {
      notice("N\xE3o houve confirma\xE7\xE3o. Confira o painel e o estado da leitura antes de tentar novamente.");
    } finally {
      batchImport.disabled = !originVerified || !accountConnected;
    }
  });
  void refreshStatus();
})();
