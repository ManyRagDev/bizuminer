"use strict";
(() => {
  // src/content/page-extractor.ts
  function collectBrowserOffers() {
    function money(label) {
      const m = /(\d[\d.]*)\s*reais(?:\s+com\s+(\d{1,2})\s*centavos)?/.exec(
        label || ""
      );
      return m ? Number(m[1].replace(/\./g, "")) * 100 + Number(m[2] || 0) : void 0;
    }
    const page = new URL(location.href);
    const normalizedPath = page.pathname.replace(/\/+$/, "");
    const blockedPaths = [
      "/gz/",
      "/login",
      "/account-verification",
      "/seguranca",
      "/checkpoint"
    ];
    const isBlocked = blockedPaths.some(
      (prefix) => normalizedPath.includes(prefix)
    );
    if (page.protocol !== "https:" || !/(^|\.)mercadolivre\.com\.br$/.test(page.hostname) || isBlocked)
      throw new Error(
        "Abra uma p\xE1gina de an\xFAncios do Mercado Livre e conclua o acesso, se solicitado."
      );
    const products = [];
    const seen = /* @__PURE__ */ new Set();
    const cards = Array.from(
      document.querySelectorAll(
        ".poly-card, .ui-search-layout__item, .ui-search-result"
      )
    );
    for (const card of cards.slice(0, 200)) {
      const anchor = card.querySelector("a.poly-component__title") || card.querySelector("a.ui-search-link") || card.querySelector(
        "a.ui-search-item__group__element"
      );
      if (!anchor) continue;
      let url;
      try {
        url = new URL(anchor.href);
      } catch {
        continue;
      }
      if (!/(^|\.)mercadolivre\.com\.br$/.test(url.hostname) || url.protocol !== "https:")
        continue;
      const direct = !url.pathname.includes("/p/") ? url.pathname.match(/\/MLB-?(\d{6,})/) : null;
      const filtered = (url.searchParams.get("pdp_filters") || "").match(
        /item_id:(MLB\d{6,})/
      );
      const fragment = new URLSearchParams(url.hash.slice(1));
      const listingId = url.searchParams.get("wid") || fragment.get("wid") || (filtered ? filtered[1] : "");
      const externalId = listingId || (direct ? "MLB" + direct[1] : "");
      const title = (anchor.textContent || "").replace(/\s+/gu, " ").trim();
      const priceEl = card.querySelector('.poly-price__current [aria-label*="reais"]') || card.querySelector(
        '.ui-search-price__second-line [aria-label*="reais"]'
      ) || card.querySelector('.price-tag [aria-label*="reais"]') || card.querySelector('[aria-label*="reais"]');
      const priceLabel = priceEl?.getAttribute("aria-label") || "";
      const priceCents = money(priceLabel || null);
      if (!/^MLB\d{6,}$/.test(externalId) || !title || title.length > 2e3 || /\b(?:faixa|entre)\b/i.test(priceLabel) || !priceCents || seen.has(externalId))
        continue;
      const originalEl = card.querySelector('[aria-label^="Antes:"]') || card.querySelector('.poly-price__original [aria-label*="reais"]') || card.querySelector(
        '.ui-search-price__original-value [aria-label*="reais"]'
      );
      const original = money(originalEl?.getAttribute("aria-label") || null);
      let text = card.textContent || "";
      for (const element of Array.from(card.querySelectorAll("[aria-label]")))
        text += " " + element.getAttribute("aria-label");
      const rating = /Classificação\s*([0-5](?:[.,]\d+)?)\s*de\s*5\s*estrelas/i.exec(text);
      const sales = /(?:\+\s*|Mais de\s+)(\d+(?:[.,]\d+)?)\s*(milhões|milhão|mil|mi|m)?\s*(?:produtos?\s+)?vendidos/i.exec(
        text
      );
      const img = card.querySelector(
        'img[src^="https://http2.mlstatic.com/"], img[src*=".mlstatic.com/"], img[data-src*=".mlstatic.com/"]'
      );
      const product = {
        externalId,
        title,
        productUrl: url.origin + url.pathname + // The listing may differ from the ID in a direct URL too. Dropping
        // its explicit identity here makes server validation see another item.
        (listingId || url.pathname.includes("/p/") ? "?wid=" + externalId : ""),
        priceCents,
        currency: "BRL",
        priceType: /a\s+partir\s+de/i.test(priceLabel) ? "from" : "exact"
      };
      if (original && original > priceCents)
        product.originalPriceCents = original;
      if (img) {
        const src = img.src && img.src.startsWith("https://") ? img.src : img.getAttribute("data-src");
        if (src && src.startsWith("https://")) product.imageUrl = src;
      }
      if (rating && Number(rating[1].replace(",", ".")) > 0)
        product.ratingStar = Number(rating[1].replace(",", "."));
      if (sales) {
        product.salesLabel = sales[0];
        product.salesCount = Math.round(
          Number(sales[1].replace(",", ".")) * (sales[2] ? sales[2] === "mil" ? 1e3 : 1e6 : 1)
        );
      }
      seen.add(externalId);
      products.push(product);
    }
    if (!products.length)
      throw new Error(
        "Nenhuma oferta completa encontrada. Confira se a listagem carregou."
      );
    const pageKind = normalizedPath.startsWith("/ofertas") ? "offers" : page.hostname.startsWith("lista.") || normalizedPath.includes("/busca/") ? "search" : normalizedPath.startsWith("/c/") ? "category" : "listing";
    const pagePath = normalizedPath || "/ofertas";
    return {
      version: 1,
      requestId: crypto.randomUUID(),
      marketplace: "mercadolivre",
      clientCapturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      page: { kind: pageKind, url: page.origin + pagePath },
      products,
      ignoredCards: cards.length - products.length
    };
  }

  // src/lib/api.ts
  var REQUEST_TIMEOUT_MS = 2e4;
  function retryAfterMs(value, now = Date.now()) {
    if (!value) return void 0;
    const delay2 = /^\d+(?:\.\d+)?$/.test(value) ? Number(value) * 1e3 : Date.parse(value) - now;
    return Number.isFinite(delay2) ? Math.max(0, delay2) : void 0;
  }
  async function postJson(opts, path, payload, requestId) {
    const controller = new AbortController();
    let timer;
    let status;
    let retryDelay;
    const retryableStatus = () => status === void 0 || status === 408 || status === 429 || status >= 500 || status >= 200 && status < 300;
    const timeout = new Promise((resolve) => {
      timer = setTimeout(() => {
        controller.abort();
        resolve({ ok: false, error: "timeout", status, retryable: retryableStatus(), retryAfterMs: retryDelay });
      }, opts.timeoutMs ?? REQUEST_TIMEOUT_MS);
    });
    const work = async () => {
      try {
        const response = await (opts.fetchImpl ?? fetch)(`${opts.baseUrl}${path}`, {
          method: "POST",
          redirect: "error",
          credentials: "omit",
          cache: "no-store",
          signal: controller.signal,
          headers: {
            "Content-Type": "application/json",
            ...opts.token ? { Authorization: `Bearer ${opts.token}` } : {},
            ...requestId ? { "Idempotency-Key": requestId } : {}
          },
          body: JSON.stringify(payload)
        });
        status = response.status;
        retryDelay = retryAfterMs(response.headers.get("retry-after"));
        const raw = await response.text();
        if (raw.length > 1e6) throw new Error("invalid_response");
        const body = JSON.parse(raw);
        if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("invalid_response");
        const data = body;
        return {
          ...data,
          ok: response.ok && data.ok === true,
          status,
          error: typeof data.error === "string" ? data.error.slice(0, 160) : data.ok === true && response.ok ? void 0 : "invalid_response",
          retryable: status === 408 || status === 429 || status >= 500 || response.ok && data.ok !== true,
          retryAfterMs: retryDelay
        };
      } catch {
        return {
          ok: false,
          error: status ? "invalid_response" : "network",
          status,
          retryable: retryableStatus(),
          retryAfterMs: retryDelay
        };
      }
    };
    try {
      return await Promise.race([work(), timeout]);
    } finally {
      clearTimeout(timer);
    }
  }
  async function postCapture(opts, payload) {
    const result = await postJson(opts, "/api/extension/captures", { ...payload, mode: "manual" }, payload.requestId);
    if (result.ok && (typeof result.productId !== "string" || !result.productId)) return { ok: false, error: "invalid_response", retryable: true };
    return result;
  }
  async function exchangePairingCode(opts, pairingCode) {
    const result = await postJson(opts, "/api/extension/pair/exchange", { pairingCode });
    if (result.ok && (typeof result.deviceId !== "string" || !result.deviceId || typeof result.deviceToken !== "string" || !result.deviceToken.startsWith("bm_ext_")))
      return { ok: false, error: "invalid_response" };
    return result;
  }

  // src/lib/storage.ts
  var BUILD_API_ORIGIN = true ? "https://www.bizuminer.com.br" : "https://www.bizuminer.com.br";
  if (!["https://www.bizuminer.com.br", "http://localhost:3100"].includes(BUILD_API_ORIGIN)) throw new Error("invalid_build_origin");
  var STORAGE_KEYS = {
    token: "bm_token",
    deviceId: "bm_device_id",
    affiliateName: "bm_affiliate_name",
    activeTabId: "bm_active_tab_id",
    outbox: "bm_outbox",
    apiBaseUrl: "bm_api_base_url",
    sessionOrigin: "bm_session_origin"
  };
  function chromeStorage() {
    return chrome.storage.local;
  }
  async function setSession(storage, session) {
    await storage.set({
      [STORAGE_KEYS.sessionOrigin]: session.origin,
      [STORAGE_KEYS.token]: session.token,
      [STORAGE_KEYS.deviceId]: session.deviceId,
      [STORAGE_KEYS.affiliateName]: session.affiliateName
    });
  }
  async function clearSession(storage) {
    await storage.set({
      [STORAGE_KEYS.sessionOrigin]: "",
      [STORAGE_KEYS.token]: "",
      [STORAGE_KEYS.deviceId]: "",
      [STORAGE_KEYS.affiliateName]: ""
    });
  }

  // src/lib/outbox.ts
  var OUTBOX_MAX_ITEMS = 200;
  var OUTBOX_TTL_MS = 30 * 60 * 1e3;
  var OUTBOX_MAX_ATTEMPTS = 6;
  var RETRY_DELAYS_MS = [5e3, 3e4, 12e4, 6e5];
  function enqueue(outbox, payload, now = Date.now()) {
    if (outbox.some((e) => e.requestId === payload.requestId)) return outbox;
    if (outbox.length >= OUTBOX_MAX_ITEMS) throw new Error("queue_full");
    const entry = {
      requestId: payload.requestId,
      payload,
      attempts: 0,
      addedAt: now,
      nextRetryAt: now
    };
    return [...outbox, entry];
  }
  function dequeue(outbox, requestId) {
    return outbox.filter((e) => e.requestId !== requestId);
  }
  function pruneExpired(outbox, now = Date.now()) {
    return outbox.map((e) => !e.stopped && (now - e.addedAt >= OUTBOX_TTL_MS || e.attempts >= OUTBOX_MAX_ATTEMPTS) ? { ...e, stopped: true, lastError: e.attempts >= OUTBOX_MAX_ATTEMPTS ? "retry_limit" : "capture_expired" } : e);
  }

  // src/lib/batch-queue.ts
  var BROWSER_BATCH_KEY = "bm_browser_batch";
  var BATCH_QUEUE_ALARM = "bm_batch_queue_retry";
  var BATCH_MAX_ATTEMPTS = 6;
  var BATCH_MAX_AGE_MS = 30 * 60 * 1e3;

  // src/lib/contracts.ts
  function pageKindFor(url) {
    let u;
    try {
      u = new URL(url);
    } catch {
      return "category";
    }
    const path = u.pathname;
    if (/(^|\.)amazon\.com\.br$/.test(u.hostname)) {
      if (/(?:dp|gp\/product)\/[A-Z0-9]{10}/i.test(path)) return "product";
      if (/\/deals/i.test(path)) return "offers";
      if (/\/b(?:\/|$)/i.test(path)) return "category";
      return "search";
    }
    if (/\/ofertas/.test(path)) return "offers";
    if (/\/p\/MLB/.test(path) || /\/MLB-\d/.test(path)) return "product";
    if (u.hostname === "lista.mercadolivre.com.br") return "search";
    if (/\/c\//.test(path)) return "category";
    return "search";
  }

  // src/lib/import-report.ts
  var IMPORT_REASON_LABELS = {
    duplicate_external_id: "Identificador repetido nesta leitura",
    product_invalid: "Dados do produto incompletos",
    product_id_invalid: "Identificador do produto inv\xE1lido",
    product_title_invalid: "Nome do produto ausente ou inv\xE1lido",
    product_url_invalid: "Endere\xE7o do produto inv\xE1lido",
    product_identity_invalid: "Endere\xE7o e identificador n\xE3o correspondem",
    product_price_invalid: "Pre\xE7o ausente ou inv\xE1lido",
    product_original_price_invalid: "Pre\xE7o de refer\xEAncia inv\xE1lido",
    product_price_range_invalid: "Faixa de pre\xE7o inv\xE1lida",
    image_url_invalid: "Endere\xE7o da imagem inv\xE1lido"
  };
  var MAX_ITEMS = 200;
  var count = (value) => Number.isSafeInteger(value) && Number(value) >= 0 && Number(value) <= MAX_ITEMS;
  function record(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
  }
  function safeId(value) {
    return typeof value === "string" && value.length <= 64 && (/^MLB\d{6,}$/.test(value) || /^[A-Z0-9]{10}$/.test(value) || /^\d{8,20}$/.test(value));
  }
  function diagnostics(value) {
    const d = record(value);
    if (!d || !count(d.received) || !count(d.valid) || !count(d.duplicates) || !count(d.rejected) || d.received !== d.valid + d.duplicates + d.rejected || !Array.isArray(d.items) || d.items.length !== d.duplicates + d.rejected || d.items.length > MAX_ITEMS) return void 0;
    const items = [];
    const indices = /* @__PURE__ */ new Set();
    for (const raw of d.items) {
      const item = record(raw);
      if (!item || !count(item.index) || item.index < 1 || item.index > d.received || indices.has(item.index) || item.status !== "duplicate" && item.status !== "rejected") return void 0;
      indices.add(item.index);
      const reason = typeof item.reason === "string" && Object.hasOwn(IMPORT_REASON_LABELS, item.reason) ? item.reason : "unknown_reason";
      items.push({
        index: item.index,
        status: item.status,
        reason,
        ...safeId(item.externalId) ? { externalId: item.externalId } : {}
      });
    }
    if (items.filter((item) => item.status === "duplicate").length !== d.duplicates || items.filter((item) => item.status === "rejected").length !== d.rejected) return void 0;
    return {
      received: d.received,
      valid: d.valid,
      duplicates: d.duplicates,
      rejected: d.rejected,
      items: items.sort((a, b) => a.index - b.index)
    };
  }
  var SAFE_ERRORS = /* @__PURE__ */ new Set([
    "invalid_payload",
    "no_valid_products",
    "network",
    "timeout",
    "invalid_response",
    "not_paired",
    "unauthorized",
    "forbidden",
    "device_revoked",
    "account_suspended",
    "capture_expired",
    "retry_limit",
    "session_changed",
    "marketplace_capture_unavailable",
    "browser_capture_forbidden",
    "request_failed",
    "storage_or_network"
  ]);
  function sanitizeImportReport(value) {
    const raw = record(value);
    if (!raw || typeof raw.requestId !== "string" || !/^[A-Za-z0-9_-]{1,128}$/.test(raw.requestId) || !Number.isSafeInteger(raw.at) || Number(raw.at) < 0 || !Number.isFinite(new Date(Number(raw.at)).getTime()) || typeof raw.ok !== "boolean") return null;
    const result = { requestId: raw.requestId, at: Number(raw.at), ok: raw.ok };
    const detail = diagnostics(raw.diagnostics);
    if (detail) result.diagnostics = detail;
    if (count(raw.importedCount) && (!detail || raw.importedCount <= detail.valid)) result.importedCount = raw.importedCount;
    if (detail && result.importedCount !== void 0 && count(raw.alreadyRecordedCount) && raw.alreadyRecordedCount + result.importedCount === detail.valid) result.alreadyRecordedCount = raw.alreadyRecordedCount;
    if (typeof raw.duplicate === "boolean") result.duplicate = raw.duplicate;
    if (typeof raw.error === "string") result.error = SAFE_ERRORS.has(raw.error) ? raw.error : "request_failed";
    return result;
  }

  // src/background/service-worker.ts
  var DEFAULT_API_BASE = BUILD_API_ORIGIN;
  async function getActiveApiBase() {
    return DEFAULT_API_BASE;
  }
  var OUTBOX_KEY = STORAGE_KEYS.outbox;
  var RETRY_ALARM = "bm_retry";
  var RECEIPTS_KEY = "bm_capture_receipts";
  var IMPORT_REPORT_KEY = "bm_last_import_report";
  var IMPORT_REPORT_TTL_MS = 24 * 60 * 60 * 1e3;
  var tail = Promise.resolve();
  function serialize(work) {
    const task = tail.then(work, work);
    tail = task.catch(() => void 0);
    return task;
  }
  async function readOutbox() {
    const data = await chromeStorage().get(OUTBOX_KEY);
    return Array.isArray(data[OUTBOX_KEY]) ? data[OUTBOX_KEY] : [];
  }
  async function writeOutbox(items) {
    await chromeStorage().set({ [OUTBOX_KEY]: items });
  }
  async function readBatch() {
    return (await chromeStorage().get(BROWSER_BATCH_KEY))[BROWSER_BATCH_KEY];
  }
  async function writeBatch(batch) {
    await chromeStorage().set({ [BROWSER_BATCH_KEY]: batch });
  }
  var matches = (item, scope2) => item.origin === scope2.origin && item.deviceId === scope2.deviceId;
  async function scope() {
    const data = await chromeStorage().get([STORAGE_KEYS.token, STORAGE_KEYS.deviceId, STORAGE_KEYS.sessionOrigin]);
    const token = data[STORAGE_KEYS.token], deviceId = data[STORAGE_KEYS.deviceId];
    return typeof token === "string" && token.startsWith("bm_ext_") && typeof deviceId === "string" && !!deviceId && data[STORAGE_KEYS.sessionOrigin] === DEFAULT_API_BASE ? { token, deviceId, origin: DEFAULT_API_BASE } : null;
  }
  async function readImportReport(current) {
    const stored = (await chromeStorage().get(IMPORT_REPORT_KEY))[IMPORT_REPORT_KEY];
    if (!stored) return null;
    const report = sanitizeImportReport(stored.report);
    if (!current || !matches(stored, current) || !report || Date.now() - report.at >= IMPORT_REPORT_TTL_MS || report.at > Date.now() + 6e4) {
      await chromeStorage().set({ [IMPORT_REPORT_KEY]: null });
      return null;
    }
    return report;
  }
  async function rememberImport(current, requestId, result, clearBatch = false) {
    const report = sanitizeImportReport({
      requestId,
      at: Date.now(),
      ok: result.ok,
      importedCount: result.importedCount,
      alreadyRecordedCount: result.alreadyRecordedCount,
      error: result.error,
      diagnostics: result.diagnostics
    });
    if (!report) throw new Error("invalid_import_report");
    await chromeStorage().set({
      [IMPORT_REPORT_KEY]: { origin: current.origin, deviceId: current.deviceId, report },
      ...clearBatch ? { [BROWSER_BATCH_KEY]: null } : {}
    });
    return report;
  }
  async function stopSession(reason) {
    await clearSession(chromeStorage());
    await chromeStorage().set({ [IMPORT_REPORT_KEY]: null });
    await writeOutbox((await readOutbox()).map((entry) => ({ ...entry, stopped: true, lastError: reason })));
    const batch = await readBatch();
    if (batch?.payload) await writeBatch({ ...batch, queued: false, stopped: true, lastError: reason });
    await chrome.alarms.clear(RETRY_ALARM);
    await chrome.alarms.clear(BATCH_QUEUE_ALARM);
  }
  async function reconcile() {
    const current = await scope();
    await readImportReport(current);
    if (!current) await clearSession(chromeStorage());
    await chromeStorage().set({ [STORAGE_KEYS.apiBaseUrl]: DEFAULT_API_BASE });
    await writeOutbox(pruneExpired(await readOutbox()).map((entry) => !entry.stopped && (!current || !matches(entry, current)) ? { ...entry, stopped: true, lastError: "session_changed" } : entry));
    const batch = await readBatch();
    if (batch?.payload && !batch.stopped) {
      const expired = Date.now() - Date.parse(batch.payload.clientCapturedAt) >= BATCH_MAX_AGE_MS;
      if (!current || !matches(batch, current) || expired || (batch.attempts ?? 0) >= BATCH_MAX_ATTEMPTS)
        await writeBatch({ ...batch, stopped: true, queued: false, lastError: !current || !matches(batch, current) ? "session_changed" : expired ? "capture_expired" : "retry_limit" });
    }
  }
  async function schedule() {
    const current = await scope();
    const items = (await readOutbox()).filter((entry) => !entry.stopped && current && matches(entry, current));
    if (items.length) await chrome.alarms.create(RETRY_ALARM, { when: Math.max(
      Date.now() + 1e3,
      Math.min(...items.map((entry) => Math.min(entry.nextRetryAt, entry.addedAt + OUTBOX_TTL_MS)))
    ) });
    else await chrome.alarms.clear(RETRY_ALARM);
    const batch = await readBatch();
    if (batch?.queued && !batch.stopped && batch.payload && current && matches(batch, current))
      await chrome.alarms.create(BATCH_QUEUE_ALARM, { when: Math.max(
        Date.now() + 1e3,
        Math.min(batch.nextRetryAt ?? Date.now(), Date.parse(batch.payload.clientCapturedAt) + BATCH_MAX_AGE_MS)
      ) });
    else await chrome.alarms.clear(BATCH_QUEUE_ALARM);
    const failed = (await readOutbox()).some((entry) => entry.stopped) || batch?.stopped;
    await chrome.action.setBadgeText({ text: failed ? "!" : items.length ? String(items.length) : batch?.queued ? "\u2026" : "" });
    if (failed || items.length || batch?.queued) await chrome.action.setBadgeBackgroundColor({ color: failed ? "#a52a24" : "#f59e0b" });
  }
  async function coordinated(work) {
    return serialize(async () => {
      await reconcile();
      try {
        return await work();
      } finally {
        await schedule();
      }
    });
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const type = message && typeof message === "object" ? message.type : "";
    const popupOnly = ["PAIR", "LOGOUT", "SET_ENV", "PREPARE_BATCH", "IMPORT_BATCH", "CANCEL_BATCH", "CLEAR_FAILED"];
    if (popupOnly.includes(type) && sender.url !== chrome.runtime.getURL("popup/index.html")) {
      sendResponse({ ok: false, error: "invalid_sender" });
      return false;
    }
    void coordinated(() => handleMessage(message)).then(sendResponse, () => sendResponse({ ok: false, error: "storage_or_network" }));
    return true;
  });
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id != null) void chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content/activate-catalog.js"] }).catch(() => {
    });
  });
  var wake = () => {
    void coordinated(async () => void 0).catch(() => {
    });
  };
  chrome.runtime.onInstalled.addListener(wake);
  chrome.runtime.onStartup.addListener(wake);
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === RETRY_ALARM) void coordinated(processDueOutbox).catch(() => {
    });
    if (alarm.name === BATCH_QUEUE_ALARM) void coordinated(async () => {
      await importBrowserBatch(true);
    }).catch(() => {
    });
  });
  wake();
  var authFailed = (result) => result.status === 401 || result.error === "unauthorized" || result.error === "device_revoked";
  var delay = (attempts, result) => Math.max(RETRY_DELAYS_MS[Math.min(attempts - 1, RETRY_DELAYS_MS.length - 1)], result.retryAfterMs ?? 0);
  async function remember(entry, result) {
    const data = await chromeStorage().get(RECEIPTS_KEY);
    const receipts = Array.isArray(data[RECEIPTS_KEY]) ? data[RECEIPTS_KEY] : [];
    await chromeStorage().set({ [RECEIPTS_KEY]: [
      ...receipts.filter((r) => Date.now() - r.at < OUTBOX_TTL_MS).slice(-199),
      { requestId: entry.requestId, origin: entry.origin, deviceId: entry.deviceId, at: Date.now(), result }
    ] });
  }
  async function deliverSingle(entry, current) {
    const sending = { ...entry, attempts: entry.attempts + 1, nextRetryAt: Date.now() + 3e4 };
    await writeOutbox((await readOutbox()).map((e) => e.requestId === entry.requestId ? sending : e));
    await schedule();
    const result = await postCapture({ baseUrl: current.origin, token: current.token }, entry.payload);
    if (result.ok) {
      await remember(sending, result);
      await writeOutbox(dequeue(await readOutbox(), entry.requestId));
    } else if (authFailed(result)) await stopSession("not_paired");
    else {
      const stopped = !result.retryable || sending.attempts >= OUTBOX_MAX_ATTEMPTS;
      await writeOutbox((await readOutbox()).map((e) => e.requestId !== entry.requestId ? e : {
        ...sending,
        stopped,
        lastError: sending.attempts >= OUTBOX_MAX_ATTEMPTS ? "retry_limit" : result.error ?? "request_failed",
        nextRetryAt: Date.now() + delay(sending.attempts, result)
      }));
    }
    return result;
  }
  async function processDueOutbox() {
    const current = await scope();
    if (!current) return;
    const entry = (await readOutbox()).find((e) => !e.stopped && matches(e, current) && e.nextRetryAt <= Date.now());
    if (entry) await deliverSingle(entry, current);
  }
  async function handleMessage(message) {
    if (!message || typeof message !== "object") return { ok: false, error: "invalid_message" };
    const msg = message;
    switch (msg.type) {
      case "GET_ENV":
        return { ok: true, baseUrl: DEFAULT_API_BASE, allowedBaseUrls: [DEFAULT_API_BASE] };
      case "SET_ENV":
        return msg.baseUrl === DEFAULT_API_BASE ? { ok: true, baseUrl: DEFAULT_API_BASE } : { ok: false, error: "invalid_url" };
      case "PAIR":
        return handlePair(msg);
      case "LOGOUT":
        await stopSession("session_changed");
        return { ok: true };
      case "CAPTURE":
        return handleCapture(msg);
      case "PREPARE_BATCH":
        return prepareBrowserBatch();
      case "IMPORT_BATCH":
        return importBrowserBatch();
      case "CANCEL_BATCH":
        await writeBatch(null);
        return { ok: true };
      case "CLEAR_FAILED":
        await writeOutbox((await readOutbox()).filter((e) => !e.stopped));
        return { ok: true };
      case "PENDING": {
        const outbox = await readOutbox();
        return {
          ok: true,
          pending: outbox.filter((e) => !e.stopped).length,
          failed: outbox.filter((e) => e.stopped).length,
          errors: outbox.filter((e) => e.stopped).map((e) => e.lastError ?? "request_failed")
        };
      }
      case "GET_BATCH_STATE": {
        const saved = await readBatch();
        const lastImport = await readImportReport(await scope());
        return saved?.payload ? {
          ok: true,
          hasBatch: true,
          queued: Boolean(saved.queued),
          stopped: Boolean(saved.stopped),
          lastError: saved.lastError,
          count: saved.payload.products.length,
          marketplace: saved.payload.marketplace,
          attempts: saved.attempts ?? 0,
          queuedAt: saved.queuedAt,
          lastImport
        } : { ok: true, hasBatch: false, lastImport };
      }
      default:
        return { ok: false, error: "unknown_message" };
    }
  }
  async function prepareBrowserBatch() {
    const current = await scope();
    if (!current) return { ok: false, error: "not_paired" };
    const saved = await readBatch();
    if (saved?.payload) return {
      ok: !saved.stopped,
      error: saved.lastError,
      preserved: true,
      count: saved.payload.products.length,
      retry: Boolean(saved.sent),
      queued: Boolean(saved.queued),
      stopped: Boolean(saved.stopped)
    };
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = tab?.url ? new URL(tab.url) : null;
    const host = url?.hostname ?? "";
    const marketplace = /(^|\.)mercadolivre\.com\.br$/.test(host) ? "mercadolivre" : /(^|\.)amazon\.com\.br$/.test(host) ? "amazon" : /(^|\.)aliexpress\.com$/.test(host) ? "aliexpress" : null;
    if (tab?.id == null || url?.protocol !== "https:" || !marketplace)
      return { ok: false, error: "offers_page_required" };
    let payload;
    try {
      const target = { tabId: tab.id };
      const results = marketplace === "mercadolivre" ? await chrome.scripting.executeScript({ target, func: collectBrowserOffers }) : await chrome.scripting.executeScript({ target, files: ["content/marketplace-page.js"] });
      payload = results[0]?.result;
    } catch (err) {
      console.error("Erro ao executar leitura de ofertas na aba ativa:", err);
      return { ok: false, error: "offers_page_required" };
    }
    if (!payload?.products.length) return {
      ok: false,
      error: "no_offers",
      diagnostics: payload && "diagnostics" in payload ? payload.diagnostics : void 0
    };
    await writeBatch({ payload, sent: false, queued: false, origin: current.origin, deviceId: current.deviceId });
    return {
      ok: true,
      count: payload.products.length,
      ignored: payload.ignoredCards,
      diagnostics: "diagnostics" in payload ? payload.diagnostics : void 0,
      sample: payload.marketplace === "aliexpress" ? payload.products[0] : void 0
    };
  }
  async function importBrowserBatch(fromAlarm = false) {
    const current = await scope();
    if (!current) return { ok: false, error: "not_paired" };
    const saved = await readBatch();
    if (!saved?.payload) return { ok: false, error: "prepare_first" };
    if (saved.stopped || !matches(saved, current)) return { ok: false, error: saved.lastError ?? "session_changed" };
    if (fromAlarm && !saved.queued || (saved.nextRetryAt ?? 0) > Date.now())
      return { ok: true, queued: Boolean(saved.queued), count: saved.payload.products.length, attempts: saved.attempts ?? 0 };
    const sending = {
      ...saved,
      sent: true,
      queued: true,
      queuedAt: saved.queuedAt ?? Date.now(),
      attempts: (saved.attempts ?? 0) + 1,
      lastAttemptAt: Date.now(),
      nextRetryAt: Date.now() + 3e4
    };
    await writeBatch(sending);
    await schedule();
    let result = await postJson(
      { baseUrl: current.origin, token: current.token },
      "/api/extension/capture-batches",
      { mode: "manual", payload: saved.payload },
      saved.payload.requestId
    );
    if (result.ok && (!Number.isSafeInteger(result.importedCount) || (result.importedCount ?? -1) < 0 || (result.importedCount ?? 0) > saved.payload.products.length))
      result = { ok: false, error: "invalid_response", retryable: true };
    if (result.ok) {
      const lastImport = await rememberImport(current, saved.payload.requestId, result, true);
      return { ...result, lastImport };
    } else if (authFailed(result)) await stopSession("not_paired");
    else {
      if (!result.retryable) await rememberImport(current, saved.payload.requestId, result);
      const stopped = !result.retryable || sending.attempts >= BATCH_MAX_ATTEMPTS;
      await writeBatch({
        ...sending,
        stopped,
        queued: !stopped,
        lastError: sending.attempts >= BATCH_MAX_ATTEMPTS ? "retry_limit" : result.error ?? "request_failed",
        nextRetryAt: Date.now() + delay(sending.attempts, result)
      });
      if (!stopped) return { ok: true, queued: true, count: saved.payload.products.length, attempts: sending.attempts, error: result.error };
    }
    return result;
  }
  async function handleCapture(msg) {
    const requestId = typeof msg.requestId === "string" ? msg.requestId : "";
    const card = msg.card;
    const pageUrl = typeof msg.pageUrl === "string" ? msg.pageUrl : "";
    if (!requestId || !card) return { ok: false, error: "invalid_message" };
    const current = await scope();
    if (!current) return { ok: false, error: "not_paired" };
    const receiptData = await chromeStorage().get(RECEIPTS_KEY);
    const receipts = Array.isArray(receiptData[RECEIPTS_KEY]) ? receiptData[RECEIPTS_KEY] : [];
    const receipt = receipts.find((r) => r.requestId === requestId && matches(r, current) && Date.now() - r.at < OUTBOX_TTL_MS);
    if (receipt) return receipt.result;
    const outbox = await readOutbox();
    const previous = outbox.find((entry) => entry.requestId === requestId);
    if (previous) return { ok: false, error: previous.stopped ? previous.lastError : "queued" };
    const marketplace = card.marketplace ?? (/(^|\.)amazon\.com\.br$/.test(new URL(pageUrl).hostname) ? "amazon" : "mercadolivre");
    const payload = {
      version: 1,
      requestId,
      marketplace,
      clientCapturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      page: { kind: pageKindFor(pageUrl), url: pageUrl },
      product: card
    };
    let next;
    try {
      next = enqueue(outbox, payload).map((e) => e.requestId === requestId ? { ...e, origin: current.origin, deviceId: current.deviceId } : e);
    } catch {
      return { ok: false, error: "queue_full" };
    }
    await writeOutbox(next);
    const result = await deliverSingle(next.find((e) => e.requestId === requestId), current);
    return result.ok || !result.retryable ? result : { ok: false, error: "queued" };
  }
  async function handlePair(msg) {
    if (typeof msg.pairingCode !== "string" || !msg.pairingCode.trim()) return { ok: false, error: "invalid_message" };
    await stopSession("session_changed");
    const result = await exchangePairingCode({ baseUrl: DEFAULT_API_BASE }, msg.pairingCode);
    if (!result.ok || !result.deviceToken || !result.deviceId) return { ok: false, error: result.error ?? "exchange_failed" };
    await setSession(chromeStorage(), {
      token: result.deviceToken,
      deviceId: result.deviceId,
      affiliateName: result.affiliate?.displayName ?? "",
      origin: DEFAULT_API_BASE
    });
    return { ok: true, baseUrl: DEFAULT_API_BASE, affiliateName: result.affiliate?.displayName ?? "" };
  }
})();
